import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    // Autorise les photos produits hébergées sur des URL externes (saisies dans l'administration).
    remotePatterns: [
      { protocol: "https", hostname: "**" },
    ],
  },
};

export default nextConfig;
