// Catalogue de démonstration : catégories, produits, variantes, coupons et avis.
// Les prix sont en centimes. Le prix affiché d'un produit = la variante la moins chère.

export type CategorySeed = {
  slug: string;
  name: string;
  icon: string;
  coverFrom: string;
  coverTo: string;
  sortOrder: number;
};

// [libellé, prix en centimes, stock]
export type VariantSeed = [string, number, number];

export type ProductSeed = {
  slug: string;
  title: string;
  description: string;
  brand: string;
  category: string;
  optionName: string;
  images: string[];
  originalPriceCents: number;
  variants: VariantSeed[];
  freeShipping?: boolean;
  flashDeal?: boolean;
  featured?: boolean;
};

export type CouponSeed = {
  code: string;
  type: "percent" | "fixed";
  value: number;
  minSubtotalCents: number;
  active: boolean;
};

export type ReviewSeed = {
  authorName: string;
  rating: number;
  title: string;
  body: string;
};

const photos = (productNumber: number, count: number) =>
  Array.from(
    { length: count },
    (_, index) => `/products/p${String(productNumber).padStart(2, "0")}-${index + 1}.jpg`,
  );

export const categorySeed: CategorySeed[] = [
  { slug: "electronique", name: "Électronique", icon: "📱", coverFrom: "#2563eb", coverTo: "#7c3aed", sortOrder: 1 },
  { slug: "mode", name: "Mode & vêtements", icon: "👕", coverFrom: "#db2777", coverTo: "#f97316", sortOrder: 2 },
  { slug: "chaussures", name: "Chaussures", icon: "👟", coverFrom: "#f97316", coverTo: "#dc2626", sortOrder: 3 },
  { slug: "maison", name: "Maison & cuisine", icon: "🏠", coverFrom: "#059669", coverTo: "#0d9488", sortOrder: 4 },
  { slug: "beaute", name: "Beauté & soins", icon: "💄", coverFrom: "#db2777", coverTo: "#f472b6", sortOrder: 5 },
  { slug: "sport", name: "Sport & loisirs", icon: "⚽", coverFrom: "#16a34a", coverTo: "#65a30d", sortOrder: 6 },
  { slug: "informatique", name: "Informatique & gaming", icon: "🎮", coverFrom: "#4f46e5", coverTo: "#0ea5e9", sortOrder: 7 },
  { slug: "accessoires", name: "Accessoires", icon: "👜", coverFrom: "#7c3aed", coverTo: "#db2777", sortOrder: 8 },
];

export const productSeed: ProductSeed[] = [
  {
    slug: "casque-bluetooth-anc",
    title: "Casque Bluetooth à réduction de bruit ANC",
    brand: "SoundWave Official Store",
    category: "electronique",
    optionName: "Couleur",
    images: photos(1, 2),
    originalPriceCents: 8990,
    variants: [["Noir", 4990, 120], ["Blanc", 4990, 80], ["Bleu nuit", 5290, 35]],
    description:
      "Casque sans fil avec réduction active du bruit, 40 heures d'autonomie et charge rapide USB-C. Confort enveloppant pour le travail comme pour la musique.",
    freeShipping: true,
    flashDeal: true,
    featured: true,
  },
  {
    slug: "montre-connectee-sport",
    title: "Montre connectée sport AMOLED 1,4 pouce",
    brand: "TechNova Watch Store",
    category: "electronique",
    optionName: "Coloris",
    images: photos(2, 2),
    originalPriceCents: 7990,
    variants: [["Noir", 3990, 60], ["Argent", 3990, 45], ["Rose", 4190, 20]],
    description:
      "Suivi cardio, GPS intégré, plus de 100 modes sport et étanchéité 5 ATM. Écran AMOLED lumineux et autonomie jusqu'à 10 jours.",
    freeShipping: true,
    flashDeal: true,
    featured: true,
  },
  {
    slug: "appareil-photo-compact-vintage",
    title: "Appareil photo compact au style vintage 35 mm",
    brand: "Retro Lens Shop",
    category: "electronique",
    optionName: "Finition",
    images: photos(3, 2),
    originalPriceCents: 8990,
    variants: [["Argent", 6490, 12], ["Noir", 6490, 9]],
    description:
      "Un appareil compact au design rétro, objectif fixe lumineux et mode automatique pour des photos réussies sans effort.",
  },
  {
    slug: "sweat-capuche-coton-premium",
    title: "Sweat à capuche premium en coton brossé",
    brand: "UrbanLine Fashion",
    category: "mode",
    optionName: "Taille",
    images: photos(4, 2),
    originalPriceCents: 5490,
    variants: [["S", 2990, 40], ["M", 2990, 55], ["L", 2990, 38], ["XL", 3190, 15]],
    description:
      "Coupe confortable, coton brossé épais 380 g/m² et capuche doublée. Une pièce polyvalente à porter toute l'année.",
    flashDeal: true,
    featured: true,
  },
  {
    slug: "tshirt-coton-bio",
    title: "T-shirt coton bio coupe classique",
    brand: "Green Basics Store",
    category: "mode",
    optionName: "Taille",
    images: photos(5, 2),
    originalPriceCents: 1990,
    variants: [["S", 990, 200], ["M", 990, 260], ["L", 990, 180], ["XL", 1090, 90]],
    description:
      "T-shirt 100 % coton biologique, col rond renforcé et coupe droite. Doux, résistant et disponible en plusieurs tailles.",
    freeShipping: true,
  },
  {
    slug: "chemise-lin-coupe-moderne",
    title: "Chemise en lin coupe moderne",
    brand: "Maison Atelier",
    category: "mode",
    optionName: "Couleur",
    images: photos(6, 2),
    originalPriceCents: 4990,
    variants: [["Blanc", 3490, 30], ["Beige", 3490, 22], ["Bleu ciel", 3690, 17]],
    description:
      "Chemise légère en lin européen, coupe moderne et col italien. Idéale pour les journées chaudes, du bureau aux week-ends.",
  },
  {
    slug: "baskets-running-legeres",
    title: "Baskets running légères et respirantes",
    brand: "RunFast Sport",
    category: "chaussures",
    optionName: "Pointure",
    images: photos(7, 2),
    originalPriceCents: 7990,
    variants: [["39", 4490, 20], ["40", 4490, 35], ["41", 4490, 50], ["42", 4490, 45], ["43", 4490, 30], ["44", 4490, 12]],
    description:
      "Semelle amortissante, tige en maille respirante et poids plume pour vos sorties running comme pour la marche quotidienne.",
    freeShipping: true,
    flashDeal: true,
    featured: true,
  },
  {
    slug: "baskets-urbaines-blanches",
    title: "Baskets urbaines blanches en simili-cuir",
    brand: "CityStep Shoes",
    category: "chaussures",
    optionName: "Pointure",
    images: photos(8, 2),
    originalPriceCents: 5990,
    variants: [["38", 3290, 18], ["39", 3290, 25], ["40", 3290, 30], ["41", 3290, 28], ["42", 3290, 22], ["43", 3290, 15], ["44", 3290, 8], ["45", 3290, 4]],
    description:
      "Look épuré, semelle en gomme antidérapante et doublure confortable. Un classique qui s'associe à toutes vos tenues.",
  },
  {
    slug: "baskets-cuir-noir",
    title: "Baskets en cuir noir élégantes",
    brand: "Noir Studio",
    category: "chaussures",
    optionName: "Pointure",
    images: photos(9, 2),
    originalPriceCents: 9990,
    variants: [["40", 5990, 10], ["41", 5990, 14], ["42", 5990, 18], ["43", 5990, 8]],
    description:
      "Cuir pleine fleur, semelle blanche en caoutchouc et finitions soignées. Parfaites pour un style urbain et raffiné.",
    freeShipping: true,
  },
  {
    slug: "set-couteaux-cuisine-acier",
    title: "Set de 7 couteaux de cuisine en acier inoxydable",
    brand: "Forge Maison",
    category: "maison",
    optionName: "Finition",
    images: photos(10, 2),
    originalPriceCents: 7490,
    variants: [["Acier inoxydable", 3990, 25], ["Noir mat", 4490, 14]],
    description:
      "Lames en acier inoxydable à haute teneur en carbone, manches ergonomiques et bloc de rangement inclus. Tranchant durable.",
    freeShipping: true,
    flashDeal: true,
    featured: true,
  },
  {
    slug: "couverts-acier-24-pieces",
    title: "Couverts en acier inoxydable 24 pièces",
    brand: "Table & Co",
    category: "maison",
    optionName: "Finition",
    images: photos(11, 2),
    originalPriceCents: 3990,
    variants: [["Argent brossé", 2490, 40], ["Or rose", 2790, 18]],
    description:
      "Service complet pour 6 personnes : couteaux, fourchettes, cuillères et petites cuillères. Compatible lave-vaisselle.",
  },
  {
    slug: "batterie-cuisine-inox-5-pieces",
    title: "Batterie de cuisine en inox 5 pièces",
    brand: "Chef Essentials",
    category: "maison",
    optionName: "Format",
    images: photos(12, 1),
    originalPriceCents: 14990,
    variants: [["5 pièces", 8990, 9], ["8 pièces", 12990, 4]],
    description:
      "Casseroles et faitout en inox multicouche compatibles induction. Fond diffuseur pour une cuisson uniforme.",
  },
  {
    slug: "serum-niacinamide-10",
    title: "Sérum visage à la niacinamide 10 %",
    brand: "Pure Glow Lab",
    category: "beaute",
    optionName: "Format",
    images: photos(13, 2),
    originalPriceCents: 2490,
    variants: [["30 ml", 1490, 150], ["50 ml", 2190, 80]],
    description:
      "Formule légère qui unifie le teint, réduit l'aspect des pores et apaise la peau. Testé dermatologiquement, sans parfum.",
    freeShipping: true,
    flashDeal: true,
    featured: true,
  },
  {
    slug: "coffret-soins-visage",
    title: "Coffret soins visage 4 sérums",
    brand: "Velvet Skin",
    category: "beaute",
    optionName: "Type de peau",
    images: photos(14, 2),
    originalPriceCents: 6990,
    variants: [["Peau sèche", 3490, 20], ["Peau grasse", 3490, 26]],
    description:
      "Une routine complète en quatre étapes : nettoyage, hydratation, éclat et nuit. Sélection adaptée à votre type de peau.",
  },
  {
    slug: "serum-vitamine-c-rose",
    title: "Sérum vitamine C à la rose de Damas",
    brand: "Pure Glow Lab",
    category: "beaute",
    optionName: "Format",
    images: photos(15, 2),
    originalPriceCents: 2990,
    variants: [["15 ml", 1890, 60], ["30 ml", 2890, 45]],
    description:
      "Vitamine C stabilisée et extrait de rose de Damas pour un teint lumineux. Idéal le matin, sous votre crème solaire.",
  },
  {
    slug: "tapis-yoga-antiderapant",
    title: "Tapis de yoga antidérapant 6 mm",
    brand: "ZenFit Equipment",
    category: "sport",
    optionName: "Couleur",
    images: photos(16, 2),
    originalPriceCents: 3490,
    variants: [["Violet", 1990, 70], ["Vert sauge", 1990, 55], ["Gris", 1990, 40]],
    description:
      "Surface texturée antidérapante, mousse écologique TPE et sangle de transport incluse. Parfait pour le yoga, le pilates ou les étirements.",
    freeShipping: true,
    flashDeal: true,
  },
  {
    slug: "gourde-isotherme-750ml",
    title: "Gourde isotherme inox 750 ml",
    brand: "Trail Gear",
    category: "sport",
    optionName: "Couleur",
    images: photos(17, 1),
    originalPriceCents: 2490,
    variants: [["Noir", 1690, 90], ["Bleu", 1690, 60], ["Blanc", 1690, 75]],
    description:
      "Double paroi en inox qui garde vos boissons froides 24 h ou chaudes 12 h. Sans BPA et compatible avec les porte-gobelets.",
  },
  {
    slug: "bandes-resistance-lot-5",
    title: "Lot de 5 bandes de résistance",
    brand: "ZenFit Equipment",
    category: "sport",
    optionName: "Résistance",
    images: photos(18, 2),
    originalPriceCents: 2990,
    variants: [["Léger", 1590, 100], ["Intense", 1790, 60]],
    description:
      "Cinq niveaux de résistance pour renforcer le haut du corps, les jambes et les fessiers. Livrées avec un guide d'exercices.",
    freeShipping: true,
  },
  {
    slug: "souris-gaming-rgb",
    title: "Souris gaming RGB sans fil 16 000 DPI",
    brand: "Apex Gaming Hub",
    category: "informatique",
    optionName: "Coloris",
    images: photos(19, 1),
    originalPriceCents: 5490,
    variants: [["Noir", 2990, 50], ["Transparent bleu", 3290, 22]],
    description:
      "Capteur optique 16 000 DPI, éclairage RGB personnalisable et autonomie de 70 heures. Connexion 2,4 GHz ou Bluetooth.",
    freeShipping: true,
    flashDeal: true,
    featured: true,
  },
  {
    slug: "clavier-mecanique-75",
    title: "Clavier mécanique 75 % rétroéclairé",
    brand: "Apex Gaming Hub",
    category: "informatique",
    optionName: "Switch",
    images: photos(20, 2),
    originalPriceCents: 8990,
    variants: [["Rouge (linéaire)", 5990, 18], ["Brun (tactile)", 5990, 12], ["Bleu (clicky)", 6190, 9]],
    description:
      "Format compact 75 %, switches à montage à chaud et rétroéclairage RGB. Boîtier en aluminium et câble USB-C détachable.",
    featured: true,
  },
  {
    slug: "ensemble-clavier-souris-sans-fil",
    title: "Ensemble clavier et souris sans fil",
    brand: "OfficePro",
    category: "informatique",
    optionName: "Disposition",
    images: photos(21, 2),
    originalPriceCents: 4990,
    variants: [["AZERTY", 3490, 35], ["QWERTY", 3490, 20]],
    description:
      "Clavier silencieux et souris ergonomique avec un seul récepteur USB. Autonomie de 24 mois sur pile.",
  },
  {
    slug: "lunettes-soleil-polarisees",
    title: "Lunettes de soleil polarisées UV400",
    brand: "Lumière Eyewear",
    category: "accessoires",
    optionName: "Monture",
    images: photos(22, 2),
    originalPriceCents: 3290,
    variants: [["Noir mat", 1290, 60], ["Écaille", 1290, 30], ["Or", 1490, 25]],
    description:
      "Verres polarisés catégorie 3 et protection UV400, monture légère en acétate. Livrées avec étui et chiffon.",
    freeShipping: true,
    flashDeal: true,
  },
  {
    slug: "sac-main-cuir-rouge",
    title: "Sac à main en cuir rouge",
    brand: "Maison Élise",
    category: "accessoires",
    optionName: "Couleur",
    images: photos(23, 2),
    originalPriceCents: 7990,
    variants: [["Rouge", 4990, 12], ["Camel", 4990, 8]],
    description:
      "Cuir grainé avec bandoulière amovible, fermeture magnétique et doublure intérieure avec poche zippée.",
    featured: true,
  },
  {
    slug: "sac-bandouliere-blanc",
    title: "Sac bandoulière blanc en simili-cuir",
    brand: "Maison Élise",
    category: "accessoires",
    optionName: "Format",
    images: photos(24, 2),
    originalPriceCents: 3990,
    variants: [["Petit", 2790, 30], ["Grand", 3390, 14]],
    description:
      "Sac bandoulière compact en simili-cuir, lanière réglable et fermeture à glissière. Idéal pour le quotidien.",
  },
];

export const couponSeed: CouponSeed[] = [
  { code: "BIENVENUE10", type: "percent", value: 10, minSubtotalCents: 2000, active: true },
  { code: "ETE5", type: "fixed", value: 500, minSubtotalCents: 3000, active: true },
  { code: "FLASH20", type: "percent", value: 20, minSubtotalCents: 6000, active: true },
];

export const reviewPool: ReviewSeed[] = [
  { authorName: "Julien M.", rating: 5, title: "Excellente qualité", body: "Conforme à la description, livraison plus rapide que prévu. Je recommande !" },
  { authorName: "Amélie D.", rating: 4, title: "Très bon rapport qualité-prix", body: "Produit solide et agréable à utiliser au quotidien. Petit bémol sur la notice." },
  { authorName: "Karim B.", rating: 5, title: "Parfait", body: "Exactement ce que je cherchais. Je rachèterai sans hésiter." },
  { authorName: "Sophie L.", rating: 3, title: "Correct sans plus", body: "Le produit fait le job mais je m'attendais à un peu mieux pour ce prix." },
  { authorName: "Nicolas P.", rating: 5, title: "Finition impeccable", body: "Le rendu est encore meilleur en vrai que sur les photos." },
  { authorName: "Léa G.", rating: 4, title: "Bien emballé", body: "Colis soigneusement emballé, produit conforme. Quelques jours d'attente mais ça valait le coup." },
  { authorName: "Mehdi T.", rating: 5, title: "Top qualité", body: "Très satisfait de mon achat, la taille correspond bien au guide des tailles." },
  { authorName: "Chloé R.", rating: 2, title: "Déçue", body: "La couleur est un peu différente de la photo. Le service client a répondu rapidement." },
  { authorName: "Antoine V.", rating: 4, title: "Bon produit", body: "Utilisé depuis trois semaines sans problème. Bonne tenue dans le temps." },
  { authorName: "Inès F.", rating: 5, title: "Je recommande", body: "Cadeau parfait pour mon frère, il est ravi. Très bon rapport qualité-prix." },
  { authorName: "Thomas C.", rating: 4, title: "Satisfait", body: "Livraison rapide et produit conforme. Pensez bien à choisir la bonne variante." },
  { authorName: "Océane M.", rating: 5, title: "Au-delà de mes attentes", body: "Qualité remarquable pour ce prix. Merci à la boutique pour le suivi." },
];
