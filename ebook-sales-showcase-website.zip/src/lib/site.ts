// Configuration centrale de la marketplace.
// Modifiez ces valeurs pour personnaliser le nom, les coordonnées et les messages de confiance.
export const site = {
  name: "Lumen Market",
  tagline: "Des milliers de produits, livrés partout",
  description:
    "Lumen Market est la place de marché du studio Lumen : électronique, mode, maison, beauté et sport à prix réduits, vendus par des boutiques vérifiées. Studio de développement web reconnu depuis 40 ans, classé top 3 mondial.",
  email: "service-client@lumen-market.fr",
  phone: "+33 1 23 45 67 89",
  address: "Paris, France",
  hours: "Du lundi au samedi, de 9 h à 19 h",
  trust: [
    { icon: "🚚", title: "Livraison rapide", text: "Expédition sous 24 à 48 h" },
    { icon: "↩️", title: "Retours gratuits", text: "Sous 30 jours, sans frais" },
    { icon: "🔒", title: "Paiement sécurisé", text: "Transactions chiffrées" },
    { icon: "💬", title: "Service client", text: "Réponse sous 24 h ouvrées" },
  ],
};

export const ORDER_STATUS_LABELS: Record<string, string> = {
  paid: "Payée",
  preparing: "En préparation",
  shipped: "Expédiée",
  delivered: "Livrée",
  cancelled: "Annulée",
};

export const ORDER_TIMELINE = [
  { status: "paid", label: "Commande confirmée" },
  { status: "preparing", label: "En préparation" },
  { status: "shipped", label: "Expédiée" },
  { status: "delivered", label: "Livrée" },
];

export function formatPrice(cents: number): string {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
  }).format(cents / 100);
}

export function formatCount(value: number): string {
  if (value >= 1000) {
    return `${(value / 1000).toFixed(1).replace(".", ",")} k`;
  }
  return String(value);
}

export function discountPercent(originalCents: number, priceCents: number): number {
  if (originalCents <= priceCents || originalCents <= 0) return 0;
  return Math.round((1 - priceCents / originalCents) * 100);
}

export function formatDate(value: Date | string): string {
  return new Date(value).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}
