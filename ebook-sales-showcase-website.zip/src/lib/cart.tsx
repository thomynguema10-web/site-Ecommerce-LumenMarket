"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export const MAX_CART_QUANTITY = 10;

export type CartItem = {
  variantId: number;
  productId: number;
  slug: string;
  title: string;
  image: string;
  label: string;
  priceCents: number;
  quantity: number;
};

type NewCartItem = Omit<CartItem, "quantity">;

type CartContextValue = {
  items: CartItem[];
  ready: boolean;
  itemCount: number;
  coupon: string | null;
  addItem: (item: NewCartItem, quantity?: number) => void;
  setQuantity: (variantId: number, quantity: number) => void;
  removeItem: (variantId: number) => void;
  clear: () => void;
  setCoupon: (code: string | null) => void;
};

type StoredCart = { items: CartItem[]; coupon: string | null };

export type QuoteLine = {
  variantId: number;
  productId: number;
  slug: string;
  title: string;
  image: string;
  label: string;
  unitPriceCents: number;
  quantity: number;
  stock: number;
  available: boolean;
  lineTotalCents: number;
  freeShipping: boolean;
};

export type QuoteResponse = {
  lines: QuoteLine[];
  itemCount: number;
  subtotalCents: number;
  discountCents: number;
  shippingMethod: string;
  shippingCents: number;
  totalCents: number;
  shippingOptions: { id: string; label: string; delay: string; priceCents: number }[];
  coupon: { code: string; type: "percent" | "fixed"; value: number; minSubtotalCents: number } | null;
  couponError: string | null;
  hasUnavailable: boolean;
};

// Demande au serveur le prix réel, le stock et les totaux du panier.
export async function fetchQuote(
  items: CartItem[],
  shippingMethod: string,
  couponCode: string | null,
): Promise<QuoteResponse> {
  const response = await fetch("/api/cart/quote", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      items: items.map((item) => ({ variantId: item.variantId, quantity: item.quantity })),
      shippingMethod,
      couponCode,
    }),
  });
  if (!response.ok) throw new Error("Impossible de calculer le panier.");
  return (await response.json()) as QuoteResponse;
}

const STORAGE_KEY = "lumen-market-cart-v1";

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [coupon, setCouponState] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  // Chargement du panier depuis le navigateur après l'hydratation.
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as StoredCart;
        if (Array.isArray(parsed.items)) setItems(parsed.items);
        if (typeof parsed.coupon === "string") setCouponState(parsed.coupon);
      }
    } catch {
      // Panier corrompu : on repart d'un panier vide.
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    const payload: StoredCart = { items, coupon };
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  }, [items, coupon, ready]);

  const addItem = useCallback((item: NewCartItem, quantity = 1) => {
    setItems((current) => {
      const existing = current.find((line) => line.variantId === item.variantId);
      if (existing) {
        return current.map((line) =>
          line.variantId === item.variantId
            ? { ...line, quantity: Math.min(MAX_CART_QUANTITY, line.quantity + quantity) }
            : line,
        );
      }
      return [...current, { ...item, quantity: Math.min(MAX_CART_QUANTITY, quantity) }];
    });
  }, []);

  const setQuantity = useCallback((variantId: number, quantity: number) => {
    const safe = Math.min(MAX_CART_QUANTITY, Math.max(1, Math.floor(quantity)));
    setItems((current) =>
      current.map((line) => (line.variantId === variantId ? { ...line, quantity: safe } : line)),
    );
  }, []);

  const removeItem = useCallback((variantId: number) => {
    setItems((current) => current.filter((line) => line.variantId !== variantId));
  }, []);

  const clear = useCallback(() => setItems([]), []);

  const setCoupon = useCallback((code: string | null) => {
    setCouponState(code ? code.trim().toUpperCase() : null);
  }, []);

  const itemCount = useMemo(() => items.reduce((sum, line) => sum + line.quantity, 0), [items]);

  const value = useMemo(
    () => ({ items, ready, itemCount, coupon, addItem, setQuantity, removeItem, clear, setCoupon }),
    [items, ready, itemCount, coupon, addItem, setQuantity, removeItem, clear, setCoupon],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartContextValue {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
