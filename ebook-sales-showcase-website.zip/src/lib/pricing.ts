// Règles de tarification partagées entre le serveur (validation) et le client (affichage).

export const FREE_SHIPPING_THRESHOLD_CENTS = 3500;

export const SHIPPING_METHODS = [
  { id: "standard", label: "Standard", delay: "5 à 10 jours ouvrés", priceCents: 499 },
  { id: "express", label: "Express", delay: "2 à 4 jours ouvrés", priceCents: 1290 },
  { id: "prioritaire", label: "Prioritaire", delay: "24 à 48 heures", priceCents: 2490 },
] as const;

export type ShippingMethodId = (typeof SHIPPING_METHODS)[number]["id"];

export function isShippingMethodId(value: unknown): value is ShippingMethodId {
  return SHIPPING_METHODS.some((method) => method.id === value);
}

export function computeShippingCents(
  methodId: ShippingMethodId,
  subtotalCents: number,
  allItemsFreeShipping: boolean,
): number {
  const method = SHIPPING_METHODS.find((item) => item.id === methodId) ?? SHIPPING_METHODS[0];
  if (method.id === "standard" && (allItemsFreeShipping || subtotalCents >= FREE_SHIPPING_THRESHOLD_CENTS)) {
    return 0;
  }
  return method.priceCents;
}

export type CouponInfo = {
  code: string;
  type: "percent" | "fixed";
  value: number;
  minSubtotalCents: number;
};

export function computeDiscountCents(coupon: CouponInfo | null, subtotalCents: number): number {
  if (!coupon || subtotalCents < coupon.minSubtotalCents) return 0;
  const raw =
    coupon.type === "percent" ? Math.floor((subtotalCents * coupon.value) / 100) : coupon.value;
  return Math.min(raw, subtotalCents);
}
