import { randomBytes, randomUUID } from "node:crypto";
import { and, eq, gte, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders, productVariants, products } from "@/db/schema";
import { ensureSeeded, findCoupon } from "@/lib/catalog";
import {
  SHIPPING_METHODS,
  computeDiscountCents,
  computeShippingCents,
  isShippingMethodId,
  type CouponInfo,
  type ShippingMethodId,
} from "@/lib/pricing";
import { formatPrice } from "@/lib/site";

export const MAX_QUANTITY_PER_LINE = 10;
const MAX_LINES = 50;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export class CheckoutError extends Error {}

export type CartLineInput = { variantId: number; quantity: number };

export type QuotedLine = {
  variantId: number;
  productId: number;
  slug: string;
  title: string;
  image: string;
  label: string;
  unitPriceCents: number;
  quantity: number;
  stock: number;
  available: boolean;
  lineTotalCents: number;
  freeShipping: boolean;
};

export type Quote = {
  lines: QuotedLine[];
  itemCount: number;
  subtotalCents: number;
  discountCents: number;
  shippingMethod: ShippingMethodId;
  shippingCents: number;
  totalCents: number;
  shippingOptions: { id: ShippingMethodId; label: string; delay: string; priceCents: number }[];
  coupon: CouponInfo | null;
  couponError: string | null;
  hasUnavailable: boolean;
};

export type ShippingInput = {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  postalCode: string;
  city: string;
  country: string;
};

export function parseLineInputs(raw: unknown): CartLineInput[] {
  if (!Array.isArray(raw)) return [];
  return raw.slice(0, MAX_LINES).flatMap((entry): CartLineInput[] => {
    if (!entry || typeof entry !== "object") return [];
    const { variantId, quantity } = entry as { variantId?: unknown; quantity?: unknown };
    const id = Number(variantId);
    const amount = Number(quantity ?? 1);
    if (!Number.isInteger(id) || id <= 0 || !Number.isFinite(amount)) return [];
    return [{ variantId: id, quantity: amount }];
  });
}

export function normalizeLines(items: CartLineInput[]): CartLineInput[] {
  const merged = new Map<number, number>();
  for (const item of items) {
    const quantity = Math.min(MAX_QUANTITY_PER_LINE, Math.max(1, Math.floor(item.quantity)));
    merged.set(item.variantId, Math.min(MAX_QUANTITY_PER_LINE, (merged.get(item.variantId) ?? 0) + quantity));
  }
  return [...merged].map(([variantId, quantity]) => ({ variantId, quantity }));
}

export function parseShipping(raw: unknown): ShippingInput {
  if (!raw || typeof raw !== "object") {
    throw new CheckoutError("Adresse de livraison manquante.");
  }
  const source = raw as Record<string, unknown>;
  const field = (key: string) => (typeof source[key] === "string" ? (source[key] as string).trim() : "");

  const shipping: ShippingInput = {
    fullName: field("fullName"),
    email: field("email").toLowerCase(),
    phone: field("phone"),
    address: field("address"),
    postalCode: field("postalCode"),
    city: field("city"),
    country: field("country"),
  };

  if (shipping.fullName.length < 2) throw new CheckoutError("Veuillez indiquer votre nom complet.");
  if (!EMAIL_PATTERN.test(shipping.email)) throw new CheckoutError("Adresse e-mail invalide.");
  if (shipping.phone.length < 6) throw new CheckoutError("Veuillez indiquer un numéro de téléphone valide.");
  if (shipping.address.length < 5) throw new CheckoutError("Veuillez indiquer une adresse complète.");
  if (shipping.postalCode.length < 3) throw new CheckoutError("Code postal invalide.");
  if (shipping.city.length < 2) throw new CheckoutError("Veuillez indiquer une ville.");
  if (shipping.country.length < 2) throw new CheckoutError("Veuillez indiquer un pays.");

  return shipping;
}

// Recalcule entièrement le panier depuis la base : prix, stock, coupon et livraison.
export async function quoteCart(input: {
  items: CartLineInput[];
  shippingMethod?: string;
  couponCode?: string | null;
}): Promise<Quote> {
  await ensureSeeded();

  const lines = normalizeLines(input.items);
  const rows =
    lines.length > 0
      ? await db
          .select({
            variantId: productVariants.id,
            productId: products.id,
            slug: products.slug,
            title: products.title,
            images: products.images,
            label: productVariants.label,
            priceCents: productVariants.priceCents,
            stock: productVariants.stock,
            published: products.published,
            freeShipping: products.freeShipping,
          })
          .from(productVariants)
          .innerJoin(products, eq(productVariants.productId, products.id))
          .where(inArray(productVariants.id, lines.map((line) => line.variantId)))
      : [];

  const rowById = new Map(rows.map((row) => [row.variantId, row]));
  const quotedLines: QuotedLine[] = [];

  for (const line of lines) {
    const row = rowById.get(line.variantId);
    if (!row || !row.published) continue;
    quotedLines.push({
      variantId: row.variantId,
      productId: row.productId,
      slug: row.slug,
      title: row.title,
      image: row.images[0] ?? "",
      label: row.label,
      unitPriceCents: row.priceCents,
      quantity: line.quantity,
      stock: row.stock,
      available: row.stock >= line.quantity,
      lineTotalCents: row.priceCents * line.quantity,
      freeShipping: row.freeShipping,
    });
  }

  const subtotalCents = quotedLines.reduce((sum, line) => sum + line.lineTotalCents, 0);
  const hasUnavailable = quotedLines.length !== lines.length || quotedLines.some((line) => !line.available);

  let coupon: CouponInfo | null = null;
  let couponError: string | null = null;
  const code = input.couponCode?.trim().toUpperCase() || null;
  if (code) {
    const row = await findCoupon(code);
    const expired = row?.expiresAt ? row.expiresAt.getTime() < Date.now() : false;
    if (!row || !row.active || expired) {
      couponError = "Ce code promo n'est pas valide.";
    } else if (subtotalCents < row.minSubtotalCents) {
      couponError = `Un minimum d'achat de ${formatPrice(row.minSubtotalCents)} est requis pour ce code.`;
    } else {
      coupon = { code: row.code, type: row.type, value: row.value, minSubtotalCents: row.minSubtotalCents };
    }
  }

  const allFree = quotedLines.length > 0 && quotedLines.every((line) => line.freeShipping);
  const shippingOptions = SHIPPING_METHODS.map((method) => ({
    id: method.id,
    label: method.label,
    delay: method.delay,
    priceCents: computeShippingCents(method.id, subtotalCents, allFree),
  }));
  const shippingMethod: ShippingMethodId = isShippingMethodId(input.shippingMethod)
    ? input.shippingMethod
    : "standard";
  const shippingCents = shippingOptions.find((option) => option.id === shippingMethod)?.priceCents ?? 0;
  const discountCents = computeDiscountCents(coupon, subtotalCents);
  const totalCents = quotedLines.length > 0 ? Math.max(0, subtotalCents - discountCents + shippingCents) : 0;

  return {
    lines: quotedLines,
    itemCount: quotedLines.reduce((sum, line) => sum + line.quantity, 0),
    subtotalCents,
    discountCents,
    shippingMethod,
    shippingCents,
    totalCents,
    shippingOptions,
    coupon,
    couponError,
    hasUnavailable,
  };
}

// Passerelle de paiement (mode démonstration).
// Remplacez ce bloc par l'appel à votre prestataire (Stripe, PayPal, Mollie...)
// qui encaisse réellement `amountCents` avant de valider la commande.
async function capturePayment(_amountCents: number, _email: string): Promise<void> {
  return;
}

export async function placeOrder(input: {
  items: CartLineInput[];
  shipping: ShippingInput;
  shippingMethod?: string;
  couponCode?: string | null;
  userId?: number | null;
}): Promise<{ id: string; orderNumber: string }> {
  const quote = await quoteCart({
    items: input.items,
    shippingMethod: input.shippingMethod,
    couponCode: input.couponCode,
  });

  if (quote.lines.length === 0) throw new CheckoutError("Votre panier est vide.");
  if (quote.hasUnavailable) {
    throw new CheckoutError(
      "Certains articles ne sont plus disponibles en quantité suffisante. Mettez votre panier à jour.",
    );
  }
  if (input.couponCode && quote.couponError) throw new CheckoutError(quote.couponError);

  await capturePayment(quote.totalCents, input.shipping.email);

  const id = randomUUID();
  const orderNumber = `LM-${new Date().getFullYear()}-${randomBytes(3).toString("hex").toUpperCase()}`;

  await db.transaction(async (tx) => {
    await tx.insert(orders).values({
      id,
      orderNumber,
      userId: input.userId ?? null,
      email: input.shipping.email,
      fullName: input.shipping.fullName,
      phone: input.shipping.phone,
      address: input.shipping.address,
      postalCode: input.shipping.postalCode,
      city: input.shipping.city,
      country: input.shipping.country,
      shippingMethod: quote.shippingMethod,
      couponCode: quote.coupon?.code ?? null,
      subtotalCents: quote.subtotalCents,
      shippingCents: quote.shippingCents,
      discountCents: quote.discountCents,
      totalCents: quote.totalCents,
      status: "paid",
    });

    for (const line of quote.lines) {
      // Décrément conditionnel : échoue proprement si le stock a changé entre-temps.
      const updated = await tx
        .update(productVariants)
        .set({ stock: sql`${productVariants.stock} - ${line.quantity}` })
        .where(and(eq(productVariants.id, line.variantId), gte(productVariants.stock, line.quantity)))
        .returning({ id: productVariants.id });

      if (updated.length === 0) {
        throw new CheckoutError(`Stock insuffisant pour « ${line.title} » (${line.label}).`);
      }

      await tx.insert(orderItems).values({
        orderId: id,
        productId: line.productId,
        variantId: line.variantId,
        title: line.title,
        variantLabel: line.label,
        image: line.image,
        unitPriceCents: line.unitPriceCents,
        quantity: line.quantity,
      });

      await tx
        .update(products)
        .set({ soldCount: sql`${products.soldCount} + ${line.quantity}` })
        .where(eq(products.id, line.productId));
    }
  });

  return { id, orderNumber };
}
