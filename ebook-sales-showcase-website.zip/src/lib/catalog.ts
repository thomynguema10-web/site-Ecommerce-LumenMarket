import { and, asc, count, desc, eq, gte, inArray, lte, ne, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import {
  categories,
  coupons,
  orderItems,
  orders,
  productVariants,
  products,
  reviews,
  users,
  wishlistItems,
} from "@/db/schema";
import { categorySeed, couponSeed, productSeed, reviewPool } from "@/db/seed-data";
import { hashPassword } from "@/lib/auth";

export const PAGE_SIZE = 24;
const ADMIN_EMAIL = "admin@lumen-market.fr";

// ---------------------------------------------------------------------------
// Initialisation du catalogue de démonstration (exécutée une seule fois)
// ---------------------------------------------------------------------------

let seedPromise: Promise<void> | null = null;

async function seedCatalog(): Promise<void> {
  const [row] = await db.select({ value: count() }).from(categories);
  if (Number(row?.value ?? 0) > 0) return;

  const passwordHash = await hashPassword(process.env.ADMIN_PASSWORD ?? "admin1234");

  await db.transaction(async (tx) => {
    const insertedCategories = await tx
      .insert(categories)
      .values(categorySeed)
      .returning({ id: categories.id, slug: categories.slug });
    const categoryIds = new Map(insertedCategories.map((category) => [category.slug, category.id]));

    for (const [index, seed] of productSeed.entries()) {
      const categoryId = categoryIds.get(seed.category);
      if (!categoryId) throw new Error(`Catégorie inconnue : ${seed.category}`);

      const minPrice = Math.min(...seed.variants.map((variant) => variant[1]));
      const [product] = await tx
        .insert(products)
        .values({
          slug: seed.slug,
          title: seed.title,
          description: seed.description,
          brand: seed.brand,
          categoryId,
          optionName: seed.optionName,
          images: seed.images,
          priceCents: minPrice,
          originalPriceCents: seed.originalPriceCents,
          soldCount: 120 + ((index * 379) % 4200),
          freeShipping: seed.freeShipping ?? false,
          flashDeal: seed.flashDeal ?? false,
          featured: seed.featured ?? false,
        })
        .returning({ id: products.id });

      await tx.insert(productVariants).values(
        seed.variants.map(([label, priceCents, stock], position) => ({
          productId: product.id,
          label,
          priceCents,
          stock,
          sortOrder: position,
        })),
      );

      const reviewCount = 3 + (index % 3);
      const productReviews = Array.from(
        { length: reviewCount },
        (_, offset) => reviewPool[(index + offset * 5) % reviewPool.length],
      );
      await tx.insert(reviews).values(
        productReviews.map((review) => ({
          productId: product.id,
          authorName: review.authorName,
          rating: review.rating,
          title: review.title,
          body: review.body,
        })),
      );

      const average = productReviews.reduce((sum, review) => sum + review.rating, 0) / reviewCount;
      await tx
        .update(products)
        .set({ ratingAverage: Math.round(average * 10) / 10, reviewCount })
        .where(eq(products.id, product.id));
    }

    await tx.insert(coupons).values(couponSeed).onConflictDoNothing({ target: coupons.code });
    await tx
      .insert(users)
      .values({ email: ADMIN_EMAIL, name: "Administrateur", passwordHash, role: "admin" })
      .onConflictDoNothing({ target: users.email });
  });
}

export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seedCatalog().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

// ---------------------------------------------------------------------------
// Requêtes produits
// ---------------------------------------------------------------------------

const productSummary = {
  id: products.id,
  slug: products.slug,
  title: products.title,
  brand: products.brand,
  images: products.images,
  priceCents: products.priceCents,
  originalPriceCents: products.originalPriceCents,
  ratingAverage: products.ratingAverage,
  reviewCount: products.reviewCount,
  soldCount: products.soldCount,
  freeShipping: products.freeShipping,
  flashDeal: products.flashDeal,
  categoryId: products.categoryId,
  categorySlug: categories.slug,
  categoryName: categories.name,
};

export type ProductSummary = {
  id: number;
  slug: string;
  title: string;
  brand: string;
  images: string[];
  priceCents: number;
  originalPriceCents: number;
  ratingAverage: number;
  reviewCount: number;
  soldCount: number;
  freeShipping: boolean;
  flashDeal: boolean;
  categoryId: number;
  categorySlug: string;
  categoryName: string;
};

function selectSummaries(options: { where?: SQL; order: SQL[]; limit: number; offset?: number }) {
  return db
    .select(productSummary)
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(and(eq(products.published, true), options.where))
    .orderBy(...options.order)
    .limit(options.limit)
    .offset(options.offset ?? 0);
}

function sortOrder(sort?: string): SQL[] {
  switch (sort) {
    case "prix-asc":
      return [asc(products.priceCents)];
    case "prix-desc":
      return [desc(products.priceCents)];
    case "note":
      return [desc(products.ratingAverage), desc(products.reviewCount)];
    case "ventes":
      return [desc(products.soldCount)];
    case "nouveautes":
      return [desc(products.createdAt)];
    default:
      return [desc(products.featured), desc(products.soldCount)];
  }
}

export type SearchFilters = {
  q?: string;
  category?: string;
  min?: number;
  max?: number;
  sort?: string;
  free?: boolean;
  page?: number;
};

export async function searchProducts(filters: SearchFilters) {
  await ensureSeeded();

  const conditions: SQL[] = [];
  if (filters.q) {
    const term = `%${filters.q.replace(/[%_]/g, "\\$&")}%`;
    conditions.push(
      sql`(${products.title} ilike ${term} or ${products.brand} ilike ${term} or ${products.description} ilike ${term})`,
    );
  }
  if (filters.category) conditions.push(eq(categories.slug, filters.category));
  if (typeof filters.min === "number") conditions.push(gte(products.priceCents, filters.min));
  if (typeof filters.max === "number") conditions.push(lte(products.priceCents, filters.max));
  if (filters.free) conditions.push(eq(products.freeShipping, true));

  const where = conditions.length > 0 ? and(...conditions) : undefined;
  const page = Math.max(1, filters.page ?? 1);

  const [items, totalRows] = await Promise.all([
    selectSummaries({
      where,
      order: sortOrder(filters.sort),
      limit: PAGE_SIZE,
      offset: (page - 1) * PAGE_SIZE,
    }),
    db
      .select({ value: count() })
      .from(products)
      .innerJoin(categories, eq(products.categoryId, categories.id))
      .where(and(eq(products.published, true), where)),
  ]);

  return { items, total: Number(totalRows[0]?.value ?? 0), page, pageSize: PAGE_SIZE };
}

export async function listCategories() {
  await ensureSeeded();
  return db
    .select({
      id: categories.id,
      slug: categories.slug,
      name: categories.name,
      icon: categories.icon,
      coverFrom: categories.coverFrom,
      coverTo: categories.coverTo,
    })
    .from(categories)
    .orderBy(asc(categories.sortOrder), asc(categories.id));
}

export async function getHomeData() {
  await ensureSeeded();
  const [featured, flash, bestSellers, newest] = await Promise.all([
    selectSummaries({ where: eq(products.featured, true), order: [desc(products.soldCount)], limit: 8 }),
    selectSummaries({ where: eq(products.flashDeal, true), order: [desc(products.soldCount)], limit: 8 }),
    selectSummaries({ order: [desc(products.soldCount)], limit: 8 }),
    selectSummaries({ order: [desc(products.createdAt)], limit: 4 }),
  ]);
  return { featured, flash, bestSellers, newest };
}

export async function getProductDetail(slug: string) {
  await ensureSeeded();
  const [row] = await db
    .select({
      ...productSummary,
      description: products.description,
      optionName: products.optionName,
    })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(and(eq(products.slug, slug), eq(products.published, true)))
    .limit(1);

  if (!row) return null;

  const [variants, productReviews] = await Promise.all([
    db
      .select()
      .from(productVariants)
      .where(eq(productVariants.productId, row.id))
      .orderBy(asc(productVariants.sortOrder), asc(productVariants.id)),
    db
      .select()
      .from(reviews)
      .where(eq(reviews.productId, row.id))
      .orderBy(desc(reviews.createdAt))
      .limit(30),
  ]);

  return { product: row, variants, reviews: productReviews };
}

export function getRelatedProducts(categoryId: number, excludeId: number) {
  return selectSummaries({
    where: and(eq(products.categoryId, categoryId), ne(products.id, excludeId)),
    order: [desc(products.soldCount)],
    limit: 4,
  });
}

export async function findCoupon(code: string) {
  await ensureSeeded();
  const [row] = await db
    .select()
    .from(coupons)
    .where(eq(coupons.code, code.toUpperCase()))
    .limit(1);
  return row ?? null;
}

// ---------------------------------------------------------------------------
// Comptes, favoris et commandes
// ---------------------------------------------------------------------------

export async function isInWishlist(userId: number, productId: number): Promise<boolean> {
  const [row] = await db
    .select({ productId: wishlistItems.productId })
    .from(wishlistItems)
    .where(and(eq(wishlistItems.userId, userId), eq(wishlistItems.productId, productId)))
    .limit(1);
  return Boolean(row);
}

export function getWishlistProducts(userId: number) {
  return db
    .select(productSummary)
    .from(wishlistItems)
    .innerJoin(products, eq(wishlistItems.productId, products.id))
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(wishlistItems.userId, userId))
    .orderBy(desc(wishlistItems.createdAt));
}

export function getUserOrders(userId: number) {
  return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

export async function getOrderDetail(orderId: string) {
  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order) return null;

  const items = await db
    .select()
    .from(orderItems)
    .where(eq(orderItems.orderId, orderId))
    .orderBy(asc(orderItems.id));

  return { order, items };
}

// ---------------------------------------------------------------------------
// Administration
// ---------------------------------------------------------------------------

export async function getAdminStats() {
  await ensureSeeded();
  const [revenue, orderCount, customerCount, productCount, lowStock, recentOrders] = await Promise.all([
    db
      .select({ value: sql<number>`coalesce(sum(${orders.totalCents}), 0)` })
      .from(orders)
      .where(ne(orders.status, "cancelled")),
    db.select({ value: count() }).from(orders),
    db.select({ value: count() }).from(users).where(eq(users.role, "customer")),
    db.select({ value: count() }).from(products),
    db.select({ value: count() }).from(productVariants).where(lte(productVariants.stock, 5)),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(8),
  ]);

  return {
    revenueCents: Number(revenue[0]?.value ?? 0),
    orderCount: Number(orderCount[0]?.value ?? 0),
    customerCount: Number(customerCount[0]?.value ?? 0),
    productCount: Number(productCount[0]?.value ?? 0),
    lowStockCount: Number(lowStock[0]?.value ?? 0),
    recentOrders,
  };
}

export function listAllOrders() {
  return db.select().from(orders).orderBy(desc(orders.createdAt)).limit(200);
}

export async function listAdminProducts() {
  await ensureSeeded();
  const [productRows, variantRows] = await Promise.all([
    db
      .select({
        id: products.id,
        slug: products.slug,
        title: products.title,
        brand: products.brand,
        priceCents: products.priceCents,
        published: products.published,
        categoryName: categories.name,
      })
      .from(products)
      .innerJoin(categories, eq(products.categoryId, categories.id))
      .orderBy(desc(products.id)),
    db
      .select()
      .from(productVariants)
      .orderBy(asc(productVariants.sortOrder), asc(productVariants.id)),
  ]);

  return productRows.map((product) => ({
    ...product,
    variants: variantRows.filter((variant) => variant.productId === product.id),
  }));
}

export function getVariantsByIds(ids: number[]) {
  if (ids.length === 0) return Promise.resolve([]);
  return db.select().from(productVariants).where(inArray(productVariants.id, ids));
}
