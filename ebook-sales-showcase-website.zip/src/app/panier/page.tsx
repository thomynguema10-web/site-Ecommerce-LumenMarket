"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { MAX_CART_QUANTITY, fetchQuote, useCart, type QuoteResponse } from "@/lib/cart";
import { FREE_SHIPPING_THRESHOLD_CENTS } from "@/lib/pricing";
import { formatPrice } from "@/lib/site";

export default function CartPage() {
  const { items, ready, coupon, setCoupon, setQuantity, removeItem } = useCart();
  const [quote, setQuote] = useState<QuoteResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [couponInput, setCouponInput] = useState("");

  const itemsKey = JSON.stringify(items.map((item) => [item.variantId, item.quantity]));

  // Prix, stock et totaux toujours recalculés par le serveur.
  useEffect(() => {
    if (!ready || items.length === 0) return;
    let active = true;
    setLoading(true);
    fetchQuote(items, "standard", coupon)
      .then((result) => {
        if (active) {
          setQuote(result);
          setError(null);
        }
      })
      .catch(() => {
        if (active) setError("Impossible de mettre à jour le panier. Réessayez.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
    // Le contenu du panier est suivi via itemsKey pour éviter les recalculs inutiles.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, itemsKey, coupon]);

  if (!ready) {
    return <div className="py-24 text-center text-slate-500">Chargement du panier...</div>;
  }

  if (items.length === 0) {
    return (
      <section className="mx-auto max-w-lg px-4 py-24 text-center">
        <p className="text-6xl" aria-hidden="true">🛒</p>
        <h1 className="mt-6 text-3xl font-extrabold text-slate-900">Votre panier est vide</h1>
        <p className="mt-3 text-slate-600">Découvrez nos ventes flash et nos best-sellers.</p>
        <Link href="/recherche" className="mt-8 inline-flex rounded-xl bg-gradient-to-r from-orange-500 to-red-500 px-6 py-3.5 font-bold text-white">
          Commencer mes achats
        </Link>
      </section>
    );
  }

  const quoteByVariant = new Map((quote?.lines ?? []).map((line) => [line.variantId, line]));
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = quote?.subtotalCents ?? 0;
  const standardOption = quote?.shippingOptions.find((option) => option.id === "standard");
  const remainingForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD_CENTS - subtotal);
  const blocked = !quote || quote.hasUnavailable;

  return (
    <section className="mx-auto max-w-7xl px-4 py-10">
      <h1 className="text-3xl font-extrabold text-slate-900">Mon panier</h1>
      <p className="mt-1 text-slate-500">{itemCount} article{itemCount > 1 ? "s" : ""}</p>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        <ul className="space-y-4 lg:col-span-2">
          {items.map((item) => {
            const line = quoteByVariant.get(item.variantId);
            const unavailable = quote ? !line || !line.available : false;
            const unitPrice = line?.unitPriceCents ?? item.priceCents;
            const stock = line?.stock;

            return (
              <li key={item.variantId} className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                <Link href={`/produit/${item.slug}`} className="relative h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-slate-100 sm:h-28 sm:w-28">
                  {item.image && <Image src={item.image} alt={item.title} fill sizes="112px" className="object-cover" />}
                </Link>

                <div className="flex flex-1 flex-col justify-between gap-3">
                  <div>
                    <Link href={`/produit/${item.slug}`} className="line-clamp-2 font-semibold text-slate-900 hover:text-orange-600">
                      {item.title}
                    </Link>
                    <p className="text-sm text-slate-500">{item.label}</p>
                    {unavailable && (
                      <p className="mt-1 text-sm font-semibold text-red-600">
                        {line
                          ? `Stock insuffisant (${line.stock} disponible${line.stock > 1 ? "s" : ""})`
                          : "Article indisponible"}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center overflow-hidden rounded-lg border border-slate-300">
                        <button
                          type="button"
                          aria-label="Diminuer la quantité"
                          onClick={() => setQuantity(item.variantId, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                          className="h-9 w-9 text-slate-700 hover:bg-slate-100 disabled:opacity-40"
                        >
                          −
                        </button>
                        <span className="w-10 text-center text-sm font-semibold">{item.quantity}</span>
                        <button
                          type="button"
                          aria-label="Augmenter la quantité"
                          onClick={() => setQuantity(item.variantId, item.quantity + 1)}
                          disabled={item.quantity >= MAX_CART_QUANTITY || (stock !== undefined && item.quantity >= stock)}
                          className="h-9 w-9 text-slate-700 hover:bg-slate-100 disabled:opacity-40"
                        >
                          +
                        </button>
                      </div>
                      <button type="button" onClick={() => removeItem(item.variantId)} className="text-sm font-medium text-slate-500 hover:text-red-600">
                        Supprimer
                      </button>
                    </div>

                    <div className="text-right">
                      <p className="text-lg font-bold text-slate-900">{formatPrice(unitPrice * item.quantity)}</p>
                      {item.quantity > 1 && <p className="text-xs text-slate-500">{formatPrice(unitPrice)} / unité</p>}
                    </div>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>

        <aside className="h-fit space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm lg:sticky lg:top-44">
          <h2 className="text-lg font-bold text-slate-900">Récapitulatif</h2>

          <div className="flex gap-2">
            <input
              value={couponInput}
              onChange={(event) => setCouponInput(event.target.value)}
              placeholder="Code promo"
              aria-label="Code promo"
              className="min-w-0 flex-1 rounded-xl border border-slate-300 px-3 py-2.5 text-sm uppercase outline-none focus:border-orange-500"
            />
            <button
              type="button"
              onClick={() => {
                setCoupon(couponInput.trim() || null);
                setCouponInput("");
              }}
              className="rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white hover:bg-orange-600"
            >
              Appliquer
            </button>
          </div>
          {coupon && (
            <div className="flex items-center justify-between rounded-xl bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
              <span>
                Code <strong>{coupon}</strong> appliqué
              </span>
              <button type="button" onClick={() => setCoupon(null)} className="font-semibold hover:underline">
                Retirer
              </button>
            </div>
          )}
          {quote?.couponError && <p className="text-xs font-medium text-rose-600">{quote.couponError}</p>}

          <dl className="space-y-2 border-t border-slate-200 pt-5 text-sm">
            <div className="flex justify-between text-slate-600">
              <dt>Articles</dt>
              <dd>{loading && !quote ? "..." : formatPrice(subtotal)}</dd>
            </div>
            {quote && quote.discountCents > 0 && (
              <div className="flex justify-between text-emerald-600">
                <dt>Réduction</dt>
                <dd>−{formatPrice(quote.discountCents)}</dd>
              </div>
            )}
            <div className="flex justify-between text-slate-600">
              <dt>Livraison standard</dt>
              <dd>
                {standardOption ? (standardOption.priceCents === 0 ? "Gratuite" : formatPrice(standardOption.priceCents)) : "—"}
              </dd>
            </div>
            <div className="flex justify-between border-t border-slate-200 pt-3 text-lg font-extrabold text-slate-900">
              <dt>Total TTC</dt>
              <dd>{formatPrice(quote?.totalCents ?? 0)}</dd>
            </div>
          </dl>

          {remainingForFreeShipping > 0 && quote && (
            <p className="rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-900">
              Plus que <strong>{formatPrice(remainingForFreeShipping)}</strong> pour la livraison standard offerte.
            </p>
          )}
          {quote?.hasUnavailable && (
            <p className="text-xs font-medium text-rose-600">Certains articles doivent être mis à jour avant de commander.</p>
          )}
          {error && <p className="text-xs font-medium text-rose-600">{error}</p>}

          <Link
            href="/commande"
            aria-disabled={blocked}
            className={`flex w-full items-center justify-center rounded-2xl bg-gradient-to-r from-orange-500 to-red-500 px-6 py-3.5 font-bold text-white shadow-lg shadow-orange-500/20 transition hover:opacity-90 ${
              blocked ? "pointer-events-none opacity-50" : ""
            }`}
          >
            Passer la commande
          </Link>
          <Link href="/recherche" className="block text-center text-sm font-medium text-orange-600 hover:underline">
            Continuer mes achats
          </Link>
        </aside>
      </div>
    </section>
  );
}
