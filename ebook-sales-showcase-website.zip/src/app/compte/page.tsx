import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { LogoutButton } from "@/components/LogoutButton";
import { ProductCard } from "@/components/ProductCard";
import { getCurrentUser, isAdmin } from "@/lib/auth";
import { getUserOrders, getWishlistProducts } from "@/lib/catalog";
import { ORDER_STATUS_LABELS, formatDate, formatPrice } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Mon compte",
  robots: { index: false, follow: false },
};

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/connexion?next=/compte");

  const [orders, wishlist] = await Promise.all([getUserOrders(user.id), getWishlistProducts(user.id)]);

  return (
    <section className="mx-auto max-w-7xl space-y-12 px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-6 rounded-3xl bg-gradient-to-r from-orange-500 to-red-500 p-8 text-white">
        <div>
          <p className="text-sm text-white/80">Bienvenue</p>
          <h1 className="mt-1 text-3xl font-extrabold">{user.name}</h1>
          <p className="mt-1 text-sm text-white/80">
            {user.email}
            {isAdmin(user) && " · Administrateur"}
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          {isAdmin(user) && (
            <Link href="/admin" className="rounded-xl bg-white px-5 py-2.5 text-sm font-semibold text-slate-900 hover:bg-amber-50">
              Administration
            </Link>
          )}
          <LogoutButton />
        </div>
      </div>

      <div>
        <h2 className="text-xl font-extrabold text-slate-900">Mes commandes</h2>
        {orders.length === 0 ? (
          <div className="mt-4 rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-slate-500">
            Vous n&apos;avez pas encore de commande.{" "}
            <Link href="/recherche" className="font-semibold text-orange-600 hover:underline">
              Découvrir les produits
            </Link>
          </div>
        ) : (
          <div className="mt-4 divide-y divide-slate-200 overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
            {orders.map((order) => (
              <Link
                key={order.id}
                href={`/commandes/${order.id}`}
                className="flex flex-wrap items-center justify-between gap-4 p-5 transition hover:bg-slate-50"
              >
                <div>
                  <p className="font-semibold text-slate-900">{order.orderNumber}</p>
                  <p className="text-sm text-slate-500">{formatDate(order.createdAt)}</p>
                </div>
                <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                  {ORDER_STATUS_LABELS[order.status] ?? order.status}
                </span>
                <p className="font-bold text-slate-900">{formatPrice(order.totalCents)}</p>
                <span className="text-sm font-semibold text-orange-600">Détails →</span>
              </Link>
            ))}
          </div>
        )}
      </div>

      <div id="favoris" className="scroll-mt-40">
        <h2 className="text-xl font-extrabold text-slate-900">Mes favoris</h2>
        {wishlist.length === 0 ? (
          <div className="mt-4 rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-slate-500">
            Aucun favori pour le moment. Cliquez sur le ♡ d&apos;un produit pour le retrouver ici.
          </div>
        ) : (
          <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
            {wishlist.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
