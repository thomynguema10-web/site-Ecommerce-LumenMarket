import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCurrentUser, isAdmin } from "@/lib/auth";
import { getOrderDetail } from "@/lib/catalog";
import { SHIPPING_METHODS } from "@/lib/pricing";
import { ORDER_STATUS_LABELS, ORDER_TIMELINE, formatDate, formatPrice } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Suivi de commande",
  robots: { index: false, follow: false },
};

type OrderPageProps = {
  params: Promise<{ id: string }>;
};

export default async function OrderPage({ params }: OrderPageProps) {
  const { id } = await params;
  const detail = await getOrderDetail(id);
  if (!detail) notFound();

  const user = await getCurrentUser();
  const { order, items } = detail;
  const canView = order.userId === null || user?.id === order.userId || isAdmin(user);
  if (!canView) notFound();

  const stepIndex = ORDER_TIMELINE.findIndex((step) => step.status === order.status);
  const cancelled = order.status === "cancelled";
  const shippingLabel = SHIPPING_METHODS.find((method) => method.id === order.shippingMethod)?.label ?? order.shippingMethod;
  const discount = order.discountCents;

  return (
    <section className="mx-auto max-w-5xl px-4 py-10">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          {!cancelled && (
            <p className="text-sm font-semibold uppercase tracking-wider text-emerald-600">Commande confirmée ✓</p>
          )}
          <h1 className="mt-2 text-3xl font-extrabold text-slate-900">Commande {order.orderNumber}</h1>
          <p className="mt-1 text-sm text-slate-500">
            Passée le {formatDate(order.createdAt)} · Confirmation envoyée à {order.email}
          </p>
        </div>
        <Link
          href={user ? "/compte" : "/recherche"}
          className="rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-semibold text-slate-800 hover:border-orange-400 hover:text-orange-600"
        >
          {user ? "Mes commandes" : "Continuer mes achats"}
        </Link>
      </div>

      <div className="mt-8 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
        <p className="mb-5 text-sm font-semibold text-slate-900">Suivi de la commande · {ORDER_STATUS_LABELS[order.status] ?? order.status}</p>
        {cancelled ? (
          <p className="font-semibold text-red-600">Cette commande a été annulée.</p>
        ) : (
          <ol className="grid gap-4 md:grid-cols-4">
            {ORDER_TIMELINE.map((step, index) => {
              const done = index <= stepIndex;
              return (
                <li key={step.status} className="flex items-center gap-3 md:flex-col md:text-center">
                  <span
                    className={`grid h-10 w-10 shrink-0 place-items-center rounded-full text-sm font-bold ${
                      done ? "bg-emerald-500 text-white" : "bg-slate-200 text-slate-500"
                    }`}
                  >
                    {done ? "✓" : index + 1}
                  </span>
                  <span className={`text-sm font-semibold ${done ? "text-slate-900" : "text-slate-400"}`}>{step.label}</span>
                </li>
              );
            })}
          </ol>
        )}
        {order.trackingNumber && (
          <p className="mt-6 rounded-xl bg-slate-50 px-4 py-3 text-sm text-slate-700">
            Numéro de suivi : <span className="font-mono font-semibold text-slate-900">{order.trackingNumber}</span>
          </p>
        )}
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <h2 className="text-lg font-bold text-slate-900">Articles</h2>
          {items.map((item) => (
            <div key={item.id} className="flex gap-4 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
              <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-slate-100">
                {item.image && <Image src={item.image} alt={item.title} fill sizes="80px" className="object-cover" />}
              </div>
              <div className="flex-1">
                <p className="font-semibold text-slate-900">{item.title}</p>
                <p className="text-sm text-slate-500">
                  {item.variantLabel} · Quantité {item.quantity}
                </p>
              </div>
              <p className="font-bold text-slate-900">{formatPrice(item.unitPriceCents * item.quantity)}</p>
            </div>
          ))}
        </div>

        <aside className="space-y-6">
          <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h2 className="text-base font-bold text-slate-900">Livraison</h2>
            <address className="mt-3 text-sm not-italic leading-6 text-slate-700">
              {order.fullName}
              <br />
              {order.address}
              <br />
              {order.postalCode} {order.city}
              <br />
              {order.country}
            </address>
            <p className="mt-3 text-sm text-slate-500">{shippingLabel}</p>
          </div>

          <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h2 className="text-base font-bold text-slate-900">Récapitulatif</h2>
            <dl className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between text-slate-600">
                <dt>Articles</dt>
                <dd>{formatPrice(order.subtotalCents)}</dd>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <dt>Réduction {order.couponCode ? `(${order.couponCode})` : ""}</dt>
                  <dd>−{formatPrice(discount)}</dd>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <dt>Livraison</dt>
                <dd>{order.shippingCents === 0 ? "Gratuite" : formatPrice(order.shippingCents)}</dd>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-3 text-base font-extrabold text-slate-900">
                <dt>Total TTC</dt>
                <dd>{formatPrice(order.totalCents)}</dd>
              </div>
            </dl>
          </div>
        </aside>
      </div>
    </section>
  );
}
