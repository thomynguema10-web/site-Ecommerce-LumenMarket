import { and, count, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

type ReviewParams = {
  params: Promise<{ slug: string }>;
};

export async function POST(request: Request, { params }: ReviewParams) {
  const user = await getCurrentUser();
  if (!user) {
    return Response.json({ error: "Connectez-vous pour laisser un avis." }, { status: 401 });
  }

  const { slug } = await params;
  const [product] = await db
    .select({ id: products.id })
    .from(products)
    .where(eq(products.slug, slug))
    .limit(1);
  if (!product) {
    return Response.json({ error: "Produit introuvable." }, { status: 404 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Requête invalide." }, { status: 400 });
  }

  const rating = Math.floor(Number(body.rating));
  const title = typeof body.title === "string" ? body.title.trim() : "";
  const text = typeof body.body === "string" ? body.body.trim() : "";

  if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
    return Response.json({ error: "Veuillez choisir une note entre 1 et 5." }, { status: 400 });
  }
  if (title.length < 3 || title.length > 120) {
    return Response.json({ error: "Le titre doit contenir entre 3 et 120 caractères." }, { status: 400 });
  }
  if (text.length < 10 || text.length > 2000) {
    return Response.json({ error: "Votre avis doit contenir entre 10 et 2000 caractères." }, { status: 400 });
  }

  const [existing] = await db
    .select({ id: reviews.id })
    .from(reviews)
    .where(and(eq(reviews.productId, product.id), eq(reviews.userId, user.id)))
    .limit(1);
  if (existing) {
    return Response.json({ error: "Vous avez déjà donné votre avis sur ce produit." }, { status: 409 });
  }

  await db.insert(reviews).values({
    productId: product.id,
    userId: user.id,
    authorName: user.name,
    rating,
    title,
    body: text,
  });

  const [aggregate] = await db
    .select({ average: sql<number>`avg(${reviews.rating})`, total: count() })
    .from(reviews)
    .where(eq(reviews.productId, product.id));

  await db
    .update(products)
    .set({
      ratingAverage: Math.round(Number(aggregate?.average ?? rating) * 10) / 10,
      reviewCount: Number(aggregate?.total ?? 1),
    })
    .where(eq(products.id, product.id));

  return Response.json({ ok: true }, { status: 201 });
}
