import { getCurrentUser } from "@/lib/auth";
import { CheckoutError, parseLineInputs, parseShipping, placeOrder } from "@/lib/checkout";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Requête invalide." }, { status: 400 });
  }

  try {
    const user = await getCurrentUser();
    const result = await placeOrder({
      items: parseLineInputs(body.items),
      shipping: parseShipping(body.shipping),
      shippingMethod: typeof body.shippingMethod === "string" ? body.shippingMethod : undefined,
      couponCode: typeof body.couponCode === "string" ? body.couponCode : null,
      userId: user?.id ?? null,
    });
    return Response.json(result, { status: 201 });
  } catch (error) {
    if (error instanceof CheckoutError) {
      return Response.json({ error: error.message }, { status: 400 });
    }
    console.error(error);
    return Response.json({ error: "Une erreur est survenue. Veuillez réessayer." }, { status: 500 });
  }
}
