import { eq } from "drizzle-orm";
import { db } from "@/db";
import { isOrderStatus, orders } from "@/db/schema";
import { getCurrentUser, isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

type AdminOrderParams = {
  params: Promise<{ id: string }>;
};

// Mise à jour du statut et du numéro de suivi d'une commande (administrateur).
export async function PATCH(request: Request, { params }: AdminOrderParams) {
  const user = await getCurrentUser();
  if (!isAdmin(user)) {
    return Response.json({ error: "Accès refusé." }, { status: 403 });
  }

  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Requête invalide." }, { status: 400 });
  }

  const updates: { status?: "paid" | "preparing" | "shipped" | "delivered" | "cancelled"; trackingNumber?: string | null; updatedAt: Date } = {
    updatedAt: new Date(),
  };

  if (body.status !== undefined) {
    if (!isOrderStatus(body.status)) {
      return Response.json({ error: "Statut invalide." }, { status: 400 });
    }
    updates.status = body.status;
  }

  if (body.trackingNumber !== undefined) {
    const tracking = typeof body.trackingNumber === "string" ? body.trackingNumber.trim() : "";
    if (tracking.length > 60) {
      return Response.json({ error: "Numéro de suivi trop long." }, { status: 400 });
    }
    updates.trackingNumber = tracking || null;
  }

  const [updated] = await db.update(orders).set(updates).where(eq(orders.id, id)).returning({ id: orders.id });
  if (!updated) {
    return Response.json({ error: "Commande introuvable." }, { status: 404 });
  }

  return Response.json({ ok: true });
}
