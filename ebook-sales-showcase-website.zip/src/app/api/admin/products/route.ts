import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, productVariants, products } from "@/db/schema";
import { getCurrentUser, isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

function slugify(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

// Création d'un produit avec ses variantes (administrateur).
export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!isAdmin(user)) {
    return Response.json({ error: "Accès refusé." }, { status: 403 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Requête invalide." }, { status: 400 });
  }

  const title = typeof body.title === "string" ? body.title.trim() : "";
  const brand = typeof body.brand === "string" ? body.brand.trim() : "";
  const description = typeof body.description === "string" ? body.description.trim() : "";
  const optionName = typeof body.optionName === "string" && body.optionName.trim() ? body.optionName.trim() : "Modèle";
  const categoryId = Number(body.categoryId);
  const originalPriceCents = Math.round(Number(body.originalPriceCents));
  const images = Array.isArray(body.images)
    ? body.images
        .filter((image): image is string => typeof image === "string" && image.trim().length > 0)
        .map((image) => image.trim())
        .slice(0, 8)
    : [];

  const variants = (Array.isArray(body.variants) ? body.variants : []).flatMap((entry) => {
    if (!entry || typeof entry !== "object") return [];
    const item = entry as Record<string, unknown>;
    const label = typeof item.label === "string" ? item.label.trim() : "";
    const stock = Math.floor(Number(item.stock));
    const priceCents = Math.round(Number(item.priceCents));
    if (!label || !Number.isFinite(stock) || stock < 0 || !Number.isFinite(priceCents) || priceCents <= 0) {
      return [];
    }
    return [{ label, stock, priceCents }];
  });

  if (title.length < 3) return Response.json({ error: "Le titre doit contenir au moins 3 caractères." }, { status: 400 });
  if (brand.length < 2) return Response.json({ error: "Indiquez le nom de la boutique." }, { status: 400 });
  if (description.length < 10) return Response.json({ error: "La description doit contenir au moins 10 caractères." }, { status: 400 });
  if (!Number.isInteger(categoryId)) return Response.json({ error: "Choisissez une catégorie." }, { status: 400 });
  if (images.length === 0) return Response.json({ error: "Ajoutez au moins une image (URL)." }, { status: 400 });
  if (variants.length === 0) return Response.json({ error: "Ajoutez au moins une variante valide." }, { status: 400 });

  const [category] = await db.select({ id: categories.id }).from(categories).where(eq(categories.id, categoryId)).limit(1);
  if (!category) return Response.json({ error: "Catégorie introuvable." }, { status: 400 });

  const minPrice = Math.min(...variants.map((variant) => variant.priceCents));
  const original = Number.isFinite(originalPriceCents) && originalPriceCents > minPrice ? originalPriceCents : minPrice;
  const slug = `${slugify(title) || "produit"}-${randomBytes(3).toString("hex")}`;

  const created = await db.transaction(async (tx) => {
    const [product] = await tx
      .insert(products)
      .values({
        slug,
        title,
        description,
        brand,
        categoryId: category.id,
        optionName,
        images,
        priceCents: minPrice,
        originalPriceCents: original,
        freeShipping: body.freeShipping === true,
        flashDeal: body.flashDeal === true,
        featured: body.featured === true,
      })
      .returning({ id: products.id, slug: products.slug });

    await tx.insert(productVariants).values(
      variants.map((variant, position) => ({
        productId: product.id,
        label: variant.label,
        priceCents: variant.priceCents,
        stock: variant.stock,
        sortOrder: position,
      })),
    );

    return product;
  });

  return Response.json(created, { status: 201 });
}
