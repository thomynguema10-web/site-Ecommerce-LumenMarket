import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { productVariants, products } from "@/db/schema";
import { getCurrentUser, isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

type VariantParams = {
  params: Promise<{ id: string }>;
};

// Mise à jour du stock ou du prix d'une variante (administrateur).
export async function PATCH(request: Request, { params }: VariantParams) {
  const user = await getCurrentUser();
  if (!isAdmin(user)) {
    return Response.json({ error: "Accès refusé." }, { status: 403 });
  }

  const { id } = await params;
  const variantId = Number(id);
  if (!Number.isInteger(variantId)) {
    return Response.json({ error: "Variante invalide." }, { status: 400 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Requête invalide." }, { status: 400 });
  }

  const updates: { stock?: number; priceCents?: number } = {};

  if (body.stock !== undefined) {
    const stock = Math.floor(Number(body.stock));
    if (!Number.isFinite(stock) || stock < 0 || stock > 100000) {
      return Response.json({ error: "Stock invalide." }, { status: 400 });
    }
    updates.stock = stock;
  }

  if (body.priceCents !== undefined) {
    const priceCents = Math.round(Number(body.priceCents));
    if (!Number.isFinite(priceCents) || priceCents <= 0) {
      return Response.json({ error: "Prix invalide." }, { status: 400 });
    }
    updates.priceCents = priceCents;
  }

  if (Object.keys(updates).length === 0) {
    return Response.json({ error: "Aucune modification à enregistrer." }, { status: 400 });
  }

  const [variant] = await db
    .update(productVariants)
    .set(updates)
    .where(eq(productVariants.id, variantId))
    .returning({ productId: productVariants.productId });

  if (!variant) {
    return Response.json({ error: "Variante introuvable." }, { status: 404 });
  }

  if (updates.priceCents !== undefined) {
    // Le prix affiché du produit correspond toujours à la variante la moins chère.
    const [aggregate] = await db
      .select({ min: sql<number>`min(${productVariants.priceCents})` })
      .from(productVariants)
      .where(eq(productVariants.productId, variant.productId));
    await db
      .update(products)
      .set({ priceCents: Number(aggregate?.min ?? updates.priceCents) })
      .where(eq(products.id, variant.productId));
  }

  return Response.json({ ok: true });
}
