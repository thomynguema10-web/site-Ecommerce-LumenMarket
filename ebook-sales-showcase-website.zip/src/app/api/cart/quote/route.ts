import { parseLineInputs, quoteCart } from "@/lib/checkout";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Requête invalide." }, { status: 400 });
  }

  try {
    const quote = await quoteCart({
      items: parseLineInputs(body.items),
      shippingMethod: typeof body.shippingMethod === "string" ? body.shippingMethod : undefined,
      couponCode: typeof body.couponCode === "string" ? body.couponCode : null,
    });
    return Response.json(quote);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Impossible de calculer le panier." }, { status: 500 });
  }
}
