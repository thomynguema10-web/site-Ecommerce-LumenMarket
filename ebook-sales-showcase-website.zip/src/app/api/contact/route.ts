import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export const dynamic = "force-dynamic";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Requête invalide." }, { status: 400 });
  }

  const name = typeof body.name === "string" ? body.name.trim() : "";
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const company = typeof body.company === "string" ? body.company.trim() : "";
  const message = typeof body.message === "string" ? body.message.trim() : "";

  if (name.length < 2 || name.length > 120) {
    return Response.json({ error: "Veuillez indiquer votre nom." }, { status: 400 });
  }
  if (!EMAIL_PATTERN.test(email) || email.length > 254) {
    return Response.json({ error: "Adresse e-mail invalide." }, { status: 400 });
  }
  if (company.length > 200) {
    return Response.json({ error: "Le nom de l'entreprise est trop long." }, { status: 400 });
  }
  if (message.length < 10 || message.length > 5000) {
    return Response.json(
      { error: "Votre message doit contenir entre 10 et 5000 caractères." },
      { status: 400 },
    );
  }

  await db.insert(contactMessages).values({
    name,
    email,
    company: company || null,
    message,
  });

  return Response.json({ ok: true }, { status: 201 });
}
