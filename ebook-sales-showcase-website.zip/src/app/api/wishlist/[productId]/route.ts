import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { products, wishlistItems } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

type WishlistParams = {
  params: Promise<{ productId: string }>;
};

// Bascule un produit dans les favoris de l'utilisateur connecté.
export async function POST(_request: Request, { params }: WishlistParams) {
  const user = await getCurrentUser();
  if (!user) {
    return Response.json({ error: "Connectez-vous pour gérer vos favoris." }, { status: 401 });
  }

  const { productId: raw } = await params;
  const productId = Number(raw);
  if (!Number.isInteger(productId) || productId <= 0) {
    return Response.json({ error: "Produit invalide." }, { status: 400 });
  }

  const [product] = await db
    .select({ id: products.id })
    .from(products)
    .where(eq(products.id, productId))
    .limit(1);
  if (!product) {
    return Response.json({ error: "Produit introuvable." }, { status: 404 });
  }

  const condition = and(eq(wishlistItems.userId, user.id), eq(wishlistItems.productId, productId));
  const [existing] = await db.select({ productId: wishlistItems.productId }).from(wishlistItems).where(condition).limit(1);

  if (existing) {
    await db.delete(wishlistItems).where(condition);
    return Response.json({ saved: false });
  }

  await db.insert(wishlistItems).values({ userId: user.id, productId }).onConflictDoNothing();
  return Response.json({ saved: true }, { status: 201 });
}
