import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/lib/cart";
import { getCurrentUser } from "@/lib/auth";
import { listCategories } from "@/lib/catalog";
import { site } from "@/lib/site";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export const metadata: Metadata = {
  title: {
    default: `${site.name} | ${site.tagline}`,
    template: `%s | ${site.name}`,
  },
  description: site.description,
  openGraph: {
    title: `${site.name} | ${site.tagline}`,
    description: site.description,
    type: "website",
    locale: "fr_FR",
  },
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const [user, categories] = await Promise.all([getCurrentUser(), listCategories()]);

  return (
    <html lang="fr">
      <body className="bg-slate-50 text-slate-900 antialiased">
        <CartProvider>
          <SiteHeader
            user={user ? { name: user.name, role: user.role } : null}
            categories={categories.map((category) => ({
              slug: category.slug,
              name: category.name,
              icon: category.icon,
            }))}
          />
          <main className="min-h-[70vh]">{children}</main>
          <SiteFooter />
        </CartProvider>
      </body>
    </html>
  );
}
