import type { Metadata } from "next";
import Link from "next/link";
import { CheckoutForm } from "@/components/CheckoutForm";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Finaliser ma commande",
  robots: { index: false, follow: false },
};

export default async function CheckoutPage() {
  const user = await getCurrentUser();

  return (
    <section className="mx-auto max-w-7xl px-4 py-10">
      <p className="text-sm font-semibold uppercase tracking-wider text-orange-600">Commande</p>
      <h1 className="mt-2 text-3xl font-extrabold text-slate-900">Finaliser ma commande</h1>

      {!user && (
        <p className="mt-4 rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-900">
          Vous avez déjà un compte ?{" "}
          <Link href="/connexion?next=/commande" className="font-semibold underline">
            Connectez-vous
          </Link>{" "}
          pour suivre vos commandes. Vous pouvez aussi commander sans compte.
        </p>
      )}

      <div className="mt-10">
        <CheckoutForm user={user ? { name: user.name, email: user.email } : null} />
      </div>
    </section>
  );
}
