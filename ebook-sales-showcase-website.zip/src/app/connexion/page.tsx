import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/AuthForm";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Connexion",
  description: "Connectez-vous à votre compte Lumen Market pour suivre vos commandes.",
};

type LoginPageProps = {
  searchParams: Promise<{ next?: string }>;
};

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const { next } = await searchParams;
  // Évite les redirections vers un autre site (open redirect).
  const safeNext = next && next.startsWith("/") && !next.startsWith("//") ? next : "/compte";

  const user = await getCurrentUser();
  if (user) redirect(safeNext);

  return (
    <section className="mx-auto grid max-w-5xl gap-12 px-4 py-14 md:grid-cols-2 md:items-center">
      <div>
        <p className="text-sm font-semibold uppercase tracking-wider text-orange-600">Mon compte</p>
        <h1 className="mt-3 text-3xl font-extrabold text-slate-900">Bienvenue sur Lumen Market</h1>
        <ul className="mt-6 space-y-3 text-slate-600">
          <li>✓ Suivez vos commandes et leur livraison</li>
          <li>✓ Gérez vos favoris et partagez vos avis</li>
          <li>✓ Retrouvez vos informations pour commander plus vite</li>
        </ul>
        <p className="mt-8 text-sm text-slate-500">
          Vous pouvez aussi{" "}
          <Link href="/recherche" className="font-semibold text-orange-600 hover:underline">
            parcourir les produits
          </Link>{" "}
          sans compte.
        </p>
      </div>
      <AuthForm next={safeNext} />
    </section>
  );
}
