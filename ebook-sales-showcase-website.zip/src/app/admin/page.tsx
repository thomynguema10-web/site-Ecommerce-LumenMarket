import Link from "next/link";
import { getAdminStats } from "@/lib/catalog";
import { ORDER_STATUS_LABELS, formatDate, formatPrice } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const stats = await getAdminStats();

  const cards = [
    { label: "Chiffre d'affaires", value: formatPrice(stats.revenueCents), alert: false },
    { label: "Commandes", value: String(stats.orderCount), alert: false },
    { label: "Clients", value: String(stats.customerCount), alert: false },
    { label: "Produits", value: String(stats.productCount), alert: false },
    { label: "Stock faible (≤ 5)", value: String(stats.lowStockCount), alert: stats.lowStockCount > 0 },
  ];

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-extrabold text-slate-900">Tableau de bord</h1>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {cards.map((card) => (
          <div key={card.label} className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{card.label}</p>
            <p className={`mt-2 text-2xl font-extrabold ${card.alert ? "text-red-600" : "text-slate-900"}`}>{card.value}</p>
          </div>
        ))}
      </div>

      <div>
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900">Dernières commandes</h2>
          <Link href="/admin/commandes" className="text-sm font-semibold text-orange-600 hover:underline">
            Tout voir →
          </Link>
        </div>
        <div className="mt-4 overflow-x-auto rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
              <tr>
                <th className="px-4 py-3">Commande</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Client</th>
                <th className="px-4 py-3">Total</th>
                <th className="px-4 py-3">Statut</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {stats.recentOrders.map((order) => (
                <tr key={order.id}>
                  <td className="px-4 py-3 font-mono text-xs">{order.orderNumber}</td>
                  <td className="px-4 py-3">{formatDate(order.createdAt)}</td>
                  <td className="px-4 py-3">{order.fullName}</td>
                  <td className="px-4 py-3 font-semibold">{formatPrice(order.totalCents)}</td>
                  <td className="px-4 py-3">{ORDER_STATUS_LABELS[order.status] ?? order.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {stats.recentOrders.length === 0 && (
            <p className="p-6 text-center text-slate-500">Aucune commande pour le moment.</p>
          )}
        </div>
      </div>
    </div>
  );
}
