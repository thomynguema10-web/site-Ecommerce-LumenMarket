import Link from "next/link";
import { ProductForm } from "@/components/admin/ProductForm";
import { StockForm } from "@/components/admin/StockForm";
import { listAdminProducts, listCategories } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export default async function AdminProductsPage() {
  const [products, categories] = await Promise.all([listAdminProducts(), listCategories()]);

  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">Produits & stocks</h1>
        <p className="mt-1 text-sm text-slate-500">{products.length} produits dans le catalogue.</p>
      </div>

      <section className="space-y-4">
        <h2 className="text-lg font-bold text-slate-900">Ajouter un produit</h2>
        <ProductForm categories={categories.map((category) => ({ id: category.id, name: category.name }))} />
      </section>

      <section className="space-y-4">
        <h2 className="text-lg font-bold text-slate-900">Catalogue, stocks et prix</h2>
        <div className="space-y-4">
          {products.map((product) => (
            <article key={product.id} className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-semibold text-slate-900">{product.title}</p>
                  <p className="text-sm text-slate-500">
                    {product.brand} · {product.categoryName}
                  </p>
                </div>
                <Link href={`/produit/${product.slug}`} className="text-sm font-semibold text-orange-600 hover:underline">
                  Voir la fiche →
                </Link>
              </div>
              <div className="mt-3 divide-y divide-slate-100">
                {product.variants.map((variant) => (
                  <StockForm
                    key={variant.id}
                    variantId={variant.id}
                    label={variant.label}
                    stock={variant.stock}
                    priceCents={variant.priceCents}
                  />
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
