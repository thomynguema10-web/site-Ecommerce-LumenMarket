import { OrderStatusForm } from "@/components/admin/OrderStatusForm";
import { listAllOrders } from "@/lib/catalog";
import { SHIPPING_METHODS } from "@/lib/pricing";
import { formatDate, formatPrice } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function AdminOrdersPage() {
  const orders = await listAllOrders();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">Commandes</h1>
        <p className="mt-1 text-sm text-slate-500">{orders.length} commande{orders.length > 1 ? "s" : ""} · Mettez à jour le statut et le suivi.</p>
      </div>

      <div className="overflow-x-auto rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
            <tr>
              <th className="px-4 py-3">Commande</th>
              <th className="px-4 py-3">Client</th>
              <th className="px-4 py-3">Livraison</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Statut & suivi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 align-top">
            {orders.map((order) => (
              <tr key={order.id}>
                <td className="px-4 py-4">
                  <p className="font-mono text-xs font-semibold text-slate-900">{order.orderNumber}</p>
                  <p className="text-xs text-slate-500">{formatDate(order.createdAt)}</p>
                  {order.couponCode && <p className="mt-1 text-xs text-emerald-600">Code {order.couponCode}</p>}
                </td>
                <td className="px-4 py-4">
                  <p className="font-medium text-slate-900">{order.fullName}</p>
                  <p className="text-xs text-slate-500">{order.email}</p>
                  <p className="text-xs text-slate-500">{order.city}, {order.country}</p>
                </td>
                <td className="px-4 py-4 text-xs text-slate-600">
                  {SHIPPING_METHODS.find((method) => method.id === order.shippingMethod)?.label ?? order.shippingMethod}
                </td>
                <td className="px-4 py-4 font-semibold text-slate-900">{formatPrice(order.totalCents)}</td>
                <td className="px-4 py-4">
                  <OrderStatusForm orderId={order.id} status={order.status} trackingNumber={order.trackingNumber} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {orders.length === 0 && <p className="p-6 text-center text-slate-500">Aucune commande pour le moment.</p>}
      </div>
    </div>
  );
}
