import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductCard } from "@/components/ProductCard";
import { ProductGallery } from "@/components/ProductGallery";
import { ProductPurchase } from "@/components/ProductPurchase";
import { ReviewForm } from "@/components/ReviewForm";
import { StarRating } from "@/components/StarRating";
import { getCurrentUser } from "@/lib/auth";
import { getProductDetail, getRelatedProducts, isInWishlist } from "@/lib/catalog";
import { FREE_SHIPPING_THRESHOLD_CENTS, SHIPPING_METHODS } from "@/lib/pricing";
import { discountPercent, formatCount, formatDate, formatPrice } from "@/lib/site";

export const dynamic = "force-dynamic";

type ProductPageProps = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  const { slug } = await params;
  const detail = await getProductDetail(slug);
  if (!detail) return { title: "Produit introuvable" };

  return {
    title: detail.product.title,
    description: detail.product.description.slice(0, 160),
    openGraph: { images: detail.product.images.slice(0, 1) },
  };
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { slug } = await params;
  const detail = await getProductDetail(slug);
  if (!detail) notFound();

  const { product, variants, reviews } = detail;
  const user = await getCurrentUser();
  const [wishlisted, related] = await Promise.all([
    user ? isInWishlist(user.id, product.id) : Promise.resolve(false),
    getRelatedProducts(product.categoryId, product.id),
  ]);

  const discount = discountPercent(product.originalPriceCents, product.priceCents);
  const express = SHIPPING_METHODS.find((method) => method.id === "express");
  const priority = SHIPPING_METHODS.find((method) => method.id === "prioritaire");

  return (
    <>
      <nav aria-label="Fil d'Ariane" className="mx-auto max-w-7xl px-4 pt-6 text-sm text-slate-500">
        <ol className="flex flex-wrap items-center gap-2">
          <li><Link href="/" className="hover:text-orange-600">Accueil</Link></li>
          <li aria-hidden="true">/</li>
          <li><Link href={`/recherche?categorie=${product.categorySlug}`} className="hover:text-orange-600">{product.categoryName}</Link></li>
          <li aria-hidden="true">/</li>
          <li className="line-clamp-1 max-w-xs font-medium text-slate-800">{product.title}</li>
        </ol>
      </nav>

      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-8 lg:grid-cols-2">
        <ProductGallery images={product.images} alt={product.title} />

        <div>
          <p className="text-sm text-slate-500">
            Vendu par <span className="font-semibold text-orange-600">{product.brand}</span>
          </p>
          <h1 className="mt-2 text-2xl font-extrabold leading-tight text-slate-900 md:text-3xl">{product.title}</h1>

          <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-slate-600">
            <StarRating value={product.ratingAverage} size="sm" />
            <span className="font-semibold text-slate-800">{product.ratingAverage.toFixed(1)}</span>
            <a href="#avis" className="hover:underline">({product.reviewCount} avis)</a>
            <span aria-hidden="true">·</span>
            <span>{formatCount(product.soldCount)} vendus</span>
          </div>

          {discount > 0 && (
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <span className="rounded-md bg-red-600 px-2 py-1 text-sm font-bold text-white">-{discount}%</span>
              <span className="text-slate-400 line-through">{formatPrice(product.originalPriceCents)}</span>
              {product.freeShipping && <span className="text-sm font-medium text-emerald-600">Livraison gratuite</span>}
            </div>
          )}

          <div className="mt-6">
            <ProductPurchase
              product={{
                id: product.id,
                slug: product.slug,
                title: product.title,
                image: product.images[0] ?? "",
              }}
              optionName={product.optionName}
              variants={variants.map((variant) => ({
                id: variant.id,
                label: variant.label,
                priceCents: variant.priceCents,
                stock: variant.stock,
              }))}
              inWishlist={wishlisted}
              loggedIn={Boolean(user)}
            />
          </div>

          <div className="mt-8 space-y-3 rounded-2xl border border-slate-200 bg-white p-5 text-sm text-slate-700">
            <p className="flex gap-3">
              <span aria-hidden="true">🚚</span>
              <span>
                <strong>Standard</strong> 5 à 10 jours ouvrés, <span className="font-medium text-emerald-600">gratuite dès {formatPrice(FREE_SHIPPING_THRESHOLD_CENTS)}</span>
              </span>
            </p>
            {express && (
              <p className="flex gap-3">
                <span aria-hidden="true">⚡</span>
                <span>
                  <strong>{express.label}</strong> {express.delay} ({formatPrice(express.priceCents)})
                  {priority && <> · <strong>{priority.label}</strong> {priority.delay}</>}
                </span>
              </p>
            )}
            <p className="flex gap-3">
              <span aria-hidden="true">↩️</span>
              <span><strong>Retours gratuits</strong> sous 30 jours.</span>
            </p>
            <p className="flex gap-3">
              <span aria-hidden="true">🛡️</span>
              <span><strong>Vendeur vérifié :</strong> {product.brand}, garantie légale de conformité.</span>
            </p>
          </div>
        </div>
      </section>

      <section id="description" className="mx-auto max-w-7xl px-4 py-10">
        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:p-10">
          <h2 className="text-xl font-extrabold text-slate-900">Description du produit</h2>
          <p className="mt-4 max-w-3xl whitespace-pre-line leading-7 text-slate-700">{product.description}</p>
          <dl className="mt-8 grid max-w-xl grid-cols-[10rem_1fr] gap-x-6 gap-y-3 text-sm">
            <dt className="text-slate-500">Catégorie</dt>
            <dd className="font-medium text-slate-900">{product.categoryName}</dd>
            <dt className="text-slate-500">Boutique</dt>
            <dd className="font-medium text-slate-900">{product.brand}</dd>
            <dt className="text-slate-500">{product.optionName}</dt>
            <dd className="font-medium text-slate-900">{variants.map((variant) => variant.label).join(", ")}</dd>
          </dl>
        </div>
      </section>

      <section id="avis" className="mx-auto max-w-7xl scroll-mt-40 px-4 py-10">
        <div className="grid gap-10 lg:grid-cols-3">
          <div className="space-y-6">
            <div className="rounded-2xl bg-white p-6 text-center shadow-sm ring-1 ring-slate-200">
              <p className="text-5xl font-extrabold text-slate-900">{product.ratingAverage.toFixed(1)}</p>
              <div className="mt-3 flex justify-center">
                <StarRating value={product.ratingAverage} size="lg" />
              </div>
              <p className="mt-2 text-sm text-slate-500">{product.reviewCount} avis clients</p>
            </div>
            <ReviewForm slug={product.slug} loggedIn={Boolean(user)} />
          </div>

          <div className="space-y-4 lg:col-span-2">
            <h2 className="text-xl font-extrabold text-slate-900">Avis clients</h2>
            {reviews.length === 0 && <p className="text-slate-500">Aucun avis pour le moment. Soyez le premier à donner le vôtre !</p>}
            {reviews.map((review) => (
              <article key={review.id} className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-orange-500 to-red-500 text-sm font-bold text-white">
                      {review.authorName.charAt(0)}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{review.authorName}</p>
                      <p className="text-xs text-slate-500">{formatDate(review.createdAt)}</p>
                    </div>
                  </div>
                  <StarRating value={review.rating} size="xs" />
                </div>
                <p className="mt-3 font-semibold text-slate-900">{review.title}</p>
                <p className="mt-1 text-sm leading-6 text-slate-600">{review.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {related.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-16 pt-6">
          <h2 className="text-xl font-extrabold text-slate-900">Vous aimerez aussi</h2>
          <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
            {related.map((item) => (
              <ProductCard key={item.id} product={item} />
            ))}
          </div>
        </section>
      )}
    </>
  );
}
