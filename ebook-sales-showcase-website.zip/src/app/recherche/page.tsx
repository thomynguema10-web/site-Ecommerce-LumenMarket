import type { Metadata } from "next";
import Link from "next/link";
import { ProductCard } from "@/components/ProductCard";
import { PAGE_SIZE, listCategories, searchProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Rechercher des produits",
  description: "Parcourez et filtrez tous les produits de Lumen Market.",
};

type SearchPageProps = {
  searchParams: Promise<{
    q?: string;
    categorie?: string;
    min?: string;
    max?: string;
    tri?: string;
    livraison?: string;
    page?: string;
  }>;
};

const SORT_OPTIONS = [
  { value: "pertinence", label: "Pertinence" },
  { value: "ventes", label: "Meilleures ventes" },
  { value: "note", label: "Meilleures notes" },
  { value: "prix-asc", label: "Prix croissant" },
  { value: "prix-desc", label: "Prix décroissant" },
  { value: "nouveautes", label: "Nouveautés" },
];

function parseEuros(value?: string): number | undefined {
  if (!value) return undefined;
  const amount = Number(value.replace(",", "."));
  return Number.isFinite(amount) && amount >= 0 ? Math.round(amount * 100) : undefined;
}

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const params = await searchParams;
  const q = params.q?.trim() ?? "";
  const categorySlug = params.categorie ?? "";
  const sort = SORT_OPTIONS.find((option) => option.value === params.tri)?.value ?? "pertinence";
  const free = params.livraison === "gratuite";
  const page = Math.max(1, Number.parseInt(params.page ?? "1", 10) || 1);
  const min = parseEuros(params.min);
  const max = parseEuros(params.max);

  const [categories, result] = await Promise.all([
    listCategories(),
    searchProducts({ q, category: categorySlug || undefined, min, max, sort, free, page }),
  ]);

  const currentCategory = categories.find((category) => category.slug === categorySlug);
  const totalPages = Math.max(1, Math.ceil(result.total / PAGE_SIZE));
  const heading = q ? `Résultats pour « ${q} »` : (currentCategory?.name ?? "Tous les produits");

  const buildHref = (overrides: Record<string, string>) => {
    const base: Record<string, string | undefined> = {
      q,
      categorie: categorySlug,
      min: params.min,
      max: params.max,
      tri: sort,
      livraison: params.livraison,
      page: String(page),
      ...overrides,
    };
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(base)) {
      if (value) search.set(key, value);
    }
    const query = search.toString();
    return query ? `/recherche?${query}` : "/recherche";
  };

  return (
    <section className="mx-auto max-w-7xl px-4 py-8">
      <nav aria-label="Fil d'Ariane" className="text-sm text-slate-500">
        <Link href="/" className="hover:text-orange-600">Accueil</Link>
        <span className="mx-2">/</span>
        <span className="text-slate-800">{currentCategory?.name ?? "Recherche"}</span>
      </nav>

      <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 md:text-3xl">{heading}</h1>
          <p className="mt-1 text-sm text-slate-500">
            {result.total} produit{result.total > 1 ? "s" : ""}
          </p>
        </div>
      </div>

      <div className="mt-6 flex gap-2 overflow-x-auto pb-2">
        <Link
          href={buildHref({ categorie: "", page: "1" })}
          className={`shrink-0 rounded-full border px-4 py-1.5 text-sm font-medium ${
            !categorySlug ? "border-orange-500 bg-orange-500 text-white" : "border-slate-300 bg-white text-slate-700 hover:border-orange-400"
          }`}
        >
          Toutes
        </Link>
        {categories.map((category) => (
          <Link
            key={category.slug}
            href={buildHref({ categorie: category.slug, page: "1" })}
            className={`shrink-0 rounded-full border px-4 py-1.5 text-sm font-medium ${
              categorySlug === category.slug
                ? "border-orange-500 bg-orange-500 text-white"
                : "border-slate-300 bg-white text-slate-700 hover:border-orange-400"
            }`}
          >
            {category.icon} {category.name}
          </Link>
        ))}
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[260px_1fr]">
        <form action="/recherche" method="get" className="h-fit space-y-6 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200 lg:sticky lg:top-44">
          {q && <input type="hidden" name="q" value={q} />}

          <div>
            <label htmlFor="filtre-categorie" className="text-sm font-semibold text-slate-900">Catégorie</label>
            <select id="filtre-categorie" name="categorie" defaultValue={categorySlug} className="mt-2 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm">
              <option value="">Toutes les catégories</option>
              {categories.map((category) => (
                <option key={category.slug} value={category.slug}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>

          <fieldset>
            <legend className="text-sm font-semibold text-slate-900">Prix (€)</legend>
            <div className="mt-2 flex items-center gap-2">
              <input name="min" type="number" min={0} step={1} placeholder="Min" defaultValue={params.min ?? ""} aria-label="Prix minimum" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
              <span className="text-slate-400">–</span>
              <input name="max" type="number" min={0} step={1} placeholder="Max" defaultValue={params.max ?? ""} aria-label="Prix maximum" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
            </div>
          </fieldset>

          <div>
            <label htmlFor="filtre-tri" className="text-sm font-semibold text-slate-900">Trier par</label>
            <select id="filtre-tri" name="tri" defaultValue={sort} className="mt-2 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm">
              {SORT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" name="livraison" value="gratuite" defaultChecked={free} className="h-4 w-4 accent-orange-500" />
            Livraison gratuite uniquement
          </label>

          <button type="submit" className="w-full rounded-xl bg-slate-900 py-2.5 text-sm font-semibold text-white transition hover:bg-orange-600">
            Appliquer les filtres
          </button>
          <Link href="/recherche" className="block text-center text-sm text-slate-500 hover:text-orange-600">
            Réinitialiser
          </Link>
        </form>

        <div>
          {result.items.length > 0 ? (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-4">
              {result.items.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
              <p className="text-4xl" aria-hidden="true">🔍</p>
              <p className="mt-4 text-lg font-semibold text-slate-900">Aucun produit ne correspond à votre recherche</p>
              <p className="mt-2 text-slate-500">Essayez d&apos;autres mots-clés ou retirez certains filtres.</p>
              <Link href="/recherche" className="mt-6 inline-flex rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-semibold text-white">
                Voir tous les produits
              </Link>
            </div>
          )}

          {totalPages > 1 && (
            <nav aria-label="Pagination" className="mt-10 flex items-center justify-center gap-4">
              {page > 1 ? (
                <Link href={buildHref({ page: String(page - 1) })} className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-semibold hover:border-orange-400">
                  ← Précédent
                </Link>
              ) : (
                <span className="px-4 py-2 text-sm text-slate-300">← Précédent</span>
              )}
              <span className="text-sm text-slate-600">
                Page {page} sur {totalPages}
              </span>
              {page < totalPages ? (
                <Link href={buildHref({ page: String(page + 1) })} className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-semibold hover:border-orange-400">
                  Suivant →
                </Link>
              ) : (
                <span className="px-4 py-2 text-sm text-slate-300">Suivant →</span>
              )}
            </nav>
          )}
        </div>
      </div>
    </section>
  );
}
