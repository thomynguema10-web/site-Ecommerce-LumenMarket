import Link from "next/link";

export default function NotFound() {
  return (
    <section className="mx-auto flex max-w-2xl flex-col items-center px-4 py-28 text-center">
      <p className="text-6xl" aria-hidden="true">🔍</p>
      <p className="mt-6 text-sm font-semibold uppercase tracking-wider text-orange-600">Erreur 404</p>
      <h1 className="mt-3 text-3xl font-extrabold text-slate-900">Cette page n&apos;existe pas</h1>
      <p className="mt-4 text-lg text-slate-600">
        Le produit ou la page recherchée a peut-être été retiré. Découvrez nos autres offres.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-4">
        <Link href="/recherche" className="rounded-xl bg-gradient-to-r from-orange-500 to-red-500 px-6 py-3.5 font-bold text-white">
          Voir les produits
        </Link>
        <Link href="/" className="rounded-xl border border-slate-300 px-6 py-3.5 font-semibold text-slate-800 hover:border-orange-400 hover:text-orange-600">
          Retour à l&apos;accueil
        </Link>
      </div>
    </section>
  );
}
