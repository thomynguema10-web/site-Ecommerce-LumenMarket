import Image from "next/image";
import Link from "next/link";
import { ContactForm } from "@/components/ContactForm";
import { FlashDeals } from "@/components/FlashDeals";
import { ProductCard } from "@/components/ProductCard";
import { getHomeData, listCategories } from "@/lib/catalog";
import { formatPrice, site } from "@/lib/site";

export const dynamic = "force-dynamic";

function SectionHeader({ title, href }: { title: string; href: string }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <h2 className="text-2xl font-extrabold text-slate-900">{title}</h2>
      <Link href={href} className="text-sm font-semibold text-orange-600 hover:underline">
        Voir tout →
      </Link>
    </div>
  );
}

export default async function HomePage() {
  const [home, categories] = await Promise.all([getHomeData(), listCategories()]);
  const heroProducts = (home.flash.length >= 4 ? home.flash : home.featured).slice(0, 4);

  return (
    <>
      {/* Accroche */}
      <section className="bg-gradient-to-br from-orange-500 via-red-500 to-rose-600 text-white">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-14 md:grid-cols-2 md:py-20">
          <div>
            <span className="inline-flex rounded-full bg-white/15 px-4 py-1.5 text-sm font-semibold backdrop-blur">
              🔥 De nouvelles offres chaque jour
            </span>
            <h1 className="mt-6 text-[clamp(2.25rem,5vw,3.75rem)] font-extrabold leading-[1.05] tracking-tight">
              Les meilleurs produits, <span className="text-amber-200">à prix cassés</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-8 text-white/90">
              Mode, électronique, maison, beauté et sport : des milliers de références proposées par des boutiques
              vérifiées, livrées partout.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/#flash" className="rounded-xl bg-white px-6 py-3.5 font-bold text-red-600 shadow-lg transition hover:bg-amber-50">
                ⚡ Voir les ventes flash
              </Link>
              <Link href="/recherche" className="rounded-xl border-2 border-white/70 px-6 py-3.5 font-bold text-white transition hover:bg-white/10">
                Tout le catalogue
              </Link>
            </div>
            <div className="mt-8 inline-flex flex-wrap items-center gap-3 rounded-2xl bg-black/15 px-5 py-3 text-sm backdrop-blur">
              <span>🎁 Première commande :</span>
              <span className="rounded-lg bg-white px-3 py-1 font-mono font-bold text-red-600">BIENVENUE10</span>
              <span>−10 % dès 20 € d&apos;achat</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {heroProducts.map((product, index) => (
              <Link
                key={product.id}
                href={`/produit/${product.slug}`}
                className={`group overflow-hidden rounded-2xl bg-white shadow-2xl transition hover:-translate-y-1 ${index % 2 === 1 ? "translate-y-6" : ""}`}
              >
                <div className="relative aspect-square bg-slate-100">
                  {product.images[0] && (
                    <Image
                      src={product.images[0]}
                      alt={product.title}
                      fill
                      priority={index < 2}
                      sizes="(min-width: 768px) 25vw, 45vw"
                      className="object-cover transition duration-500 group-hover:scale-105"
                    />
                  )}
                </div>
                <div className="p-3 text-slate-900">
                  <p className="line-clamp-1 text-sm font-medium">{product.title}</p>
                  <p className="font-bold text-red-600">{formatPrice(product.priceCents)}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Garanties */}
      <section className="border-b border-slate-200 bg-white">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-4 py-6 md:grid-cols-4">
          {site.trust.map((item) => (
            <div key={item.title} className="flex items-center gap-3">
              <span className="text-2xl" aria-hidden="true">{item.icon}</span>
              <div>
                <p className="text-sm font-bold text-slate-900">{item.title}</p>
                <p className="text-xs text-slate-500">{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Catégories */}
      <section id="categories" className="mx-auto max-w-7xl px-4 py-12">
        <h2 className="text-2xl font-extrabold text-slate-900">Acheter par catégorie</h2>
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-8">
          {categories.map((category) => (
            <Link
              key={category.slug}
              href={`/recherche?categorie=${category.slug}`}
              className="group flex flex-col items-center gap-3 rounded-2xl bg-white p-4 text-center shadow-sm ring-1 ring-slate-200 transition hover:-translate-y-0.5 hover:shadow-md"
            >
              <span
                className="grid h-16 w-16 place-items-center rounded-2xl text-3xl"
                style={{ backgroundImage: `linear-gradient(135deg, ${category.coverFrom}, ${category.coverTo})` }}
                aria-hidden="true"
              >
                {category.icon}
              </span>
              <span className="text-sm font-semibold text-slate-800 group-hover:text-orange-600">{category.name}</span>
            </Link>
          ))}
        </div>
      </section>

      <FlashDeals products={home.flash} />

      {/* Sélection */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <SectionHeader title="Recommandé pour vous" href="/recherche" />
        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {home.featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Nouveautés */}
      {home.newest.length > 0 && (
        <section className="bg-white">
          <div className="mx-auto max-w-7xl px-4 py-12">
            <SectionHeader title="Nouveautés" href="/recherche?tri=nouveautes" />
            <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
              {home.newest.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Plus vendus */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <SectionHeader title="Les plus vendus" href="/recherche?tri=ventes" />
        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {home.bestSellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Avantages */}
      <section className="mx-auto max-w-7xl px-4 pb-12">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="rounded-3xl bg-gradient-to-br from-indigo-600 to-violet-600 p-8 text-white">
            <p className="text-sm font-semibold uppercase tracking-wider text-white/80">Livraison offerte</p>
            <h3 className="mt-2 text-2xl font-extrabold">Dès 35 € d&apos;achat</h3>
            <p className="mt-3 text-white/85">Profitez de la livraison standard gratuite sur votre panier et sur les produits éligibles.</p>
            <Link href="/recherche?livraison=gratuite" className="mt-6 inline-flex rounded-xl bg-white px-5 py-2.5 font-semibold text-indigo-700">
              Voir les produits éligibles
            </Link>
          </div>
          <div className="rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 p-8 text-white">
            <p className="text-sm font-semibold uppercase tracking-wider text-white/80">Retours simplifiés</p>
            <h3 className="mt-2 text-2xl font-extrabold">Satisfait ou remboursé</h3>
            <p className="mt-3 text-white/85">Vous avez 30 jours pour changer d&apos;avis. Nous prenons en charge les frais de retour.</p>
            <Link href="/#contact" className="mt-6 inline-flex rounded-xl bg-white px-5 py-2.5 font-semibold text-emerald-700">
              Contacter le service client
            </Link>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="border-t border-slate-200 bg-white py-16">
        <div className="mx-auto grid max-w-7xl gap-12 px-4 md:grid-cols-5">
          <div className="md:col-span-2">
            <p className="text-sm font-semibold uppercase tracking-wider text-orange-600">Service client</p>
            <h2 className="mt-2 text-3xl font-extrabold text-slate-900">Une question sur une commande ?</h2>
            <p className="mt-4 leading-7 text-slate-600">
              Écrivez-nous à{" "}
              <a href={`mailto:${site.email}`} className="font-semibold text-orange-600 hover:underline">
                {site.email}
              </a>{" "}
              ou utilisez le formulaire. Nous répondons sous 24 heures ouvrées.
            </p>
            <p className="mt-3 text-sm text-slate-500">{site.hours}</p>
          </div>
          <div className="rounded-3xl border border-slate-200 bg-slate-50/60 p-8 md:col-span-3">
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  );
}
