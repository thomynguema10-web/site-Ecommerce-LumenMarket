"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { MAX_CART_QUANTITY, useCart } from "@/lib/cart";
import { formatPrice } from "@/lib/site";

type Variant = { id: number; label: string; priceCents: number; stock: number };

type ProductPurchaseProps = {
  product: { id: number; slug: string; title: string; image: string };
  optionName: string;
  variants: Variant[];
  inWishlist: boolean;
  loggedIn: boolean;
};

export function ProductPurchase({ product, optionName, variants, inWishlist, loggedIn }: ProductPurchaseProps) {
  const router = useRouter();
  const { addItem } = useCart();

  const firstAvailable = variants.find((variant) => variant.stock > 0) ?? variants[0];
  const [selectedId, setSelectedId] = useState(firstAvailable.id);
  const [quantity, setQuantity] = useState(1);
  const [saved, setSaved] = useState(inWishlist);
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const selected = variants.find((variant) => variant.id === selectedId) ?? firstAvailable;
  const outOfStock = selected.stock <= 0;
  const maxQuantity = Math.max(1, Math.min(MAX_CART_QUANTITY, selected.stock));
  const qty = Math.min(quantity, maxQuantity);

  function selectVariant(id: number) {
    setSelectedId(id);
    setQuantity(1);
    setMessage(null);
  }

  function addToCart() {
    addItem(
      {
        variantId: selected.id,
        productId: product.id,
        slug: product.slug,
        title: product.title,
        image: product.image,
        label: selected.label,
        priceCents: selected.priceCents,
      },
      qty,
    );
    setMessage("Ajouté au panier ✓");
  }

  function buyNow() {
    addToCart();
    router.push("/commande");
  }

  async function toggleWishlist() {
    if (!loggedIn) {
      router.push(`/connexion?next=${encodeURIComponent(`/produit/${product.slug}`)}`);
      return;
    }

    setBusy(true);
    try {
      const response = await fetch(`/api/wishlist/${product.id}`, { method: "POST" });
      const data = (await response.json().catch(() => null)) as { saved?: boolean; error?: string } | null;
      if (!response.ok) {
        setMessage(data?.error ?? "Impossible de modifier vos favoris.");
        return;
      }
      setSaved(Boolean(data?.saved));
      setMessage(data?.saved ? "Ajouté à vos favoris ♥" : "Retiré de vos favoris.");
    } catch {
      setMessage("Connexion impossible. Réessayez.");
    } finally {
      setBusy(false);
    }
  }

  const stockMessage = outOfStock
    ? "Rupture de stock"
    : selected.stock <= 5
      ? `Plus que ${selected.stock} en stock !`
      : "En stock, expédié rapidement";
  const stockClass = outOfStock ? "text-red-600" : selected.stock <= 5 ? "text-amber-600" : "text-emerald-600";

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm font-semibold text-slate-800">
          {optionName} : <span className="font-normal text-slate-500">{selected.label}</span>
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          {variants.map((variant) => {
            const active = variant.id === selected.id;
            const disabled = variant.stock <= 0;
            return (
              <button
                key={variant.id}
                type="button"
                disabled={disabled}
                onClick={() => selectVariant(variant.id)}
                className={`min-w-14 rounded-lg border-2 px-4 py-2 text-sm font-medium transition ${
                  active
                    ? "border-orange-500 bg-orange-50 text-orange-700"
                    : "border-slate-200 bg-white text-slate-700 hover:border-slate-400"
                } ${disabled ? "cursor-not-allowed line-through opacity-40" : ""}`}
              >
                {variant.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex flex-wrap items-end gap-3">
        <span className="text-4xl font-extrabold text-red-600">{formatPrice(selected.priceCents)}</span>
        <span className={`pb-1 text-sm font-medium ${stockClass}`}>{stockMessage}</span>
      </div>

      <div className="flex items-center gap-4">
        <span className="text-sm font-semibold text-slate-800">Quantité</span>
        <div className="flex items-center overflow-hidden rounded-lg border border-slate-300">
          <button
            type="button"
            aria-label="Diminuer la quantité"
            onClick={() => setQuantity(Math.max(1, qty - 1))}
            disabled={outOfStock || qty <= 1}
            className="h-10 w-10 text-lg text-slate-700 hover:bg-slate-100 disabled:opacity-40"
          >
            −
          </button>
          <span className="w-12 text-center font-semibold">{qty}</span>
          <button
            type="button"
            aria-label="Augmenter la quantité"
            onClick={() => setQuantity(Math.min(maxQuantity, qty + 1))}
            disabled={outOfStock || qty >= maxQuantity}
            className="h-10 w-10 text-lg text-slate-700 hover:bg-slate-100 disabled:opacity-40"
          >
            +
          </button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <button
          type="button"
          onClick={addToCart}
          disabled={outOfStock}
          className="rounded-xl border-2 border-orange-500 px-6 py-3.5 font-bold text-orange-600 transition hover:bg-orange-50 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Ajouter au panier
        </button>
        <button
          type="button"
          onClick={buyNow}
          disabled={outOfStock}
          className="rounded-xl bg-gradient-to-r from-orange-500 to-red-500 px-6 py-3.5 font-bold text-white shadow-lg shadow-orange-500/20 transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Acheter maintenant
        </button>
      </div>

      <div className="flex flex-wrap items-center gap-4 text-sm">
        <button
          type="button"
          onClick={toggleWishlist}
          disabled={busy}
          className={`font-semibold transition ${saved ? "text-red-600" : "text-slate-600 hover:text-red-600"}`}
        >
          {saved ? "♥ Dans vos favoris" : "♡ Ajouter aux favoris"}
        </button>
        {message && (
          <p role="status" className="font-medium text-emerald-700">
            {message}
          </p>
        )}
      </div>
    </div>
  );
}
