"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { ProductSummary } from "@/lib/catalog";
import { ProductCard } from "./ProductCard";

function formatRemaining(ms: number): [string, string, string] {
  const total = Math.max(0, Math.floor(ms / 1000));
  const pad = (value: number) => String(value).padStart(2, "0");
  return [pad(Math.floor(total / 3600)), pad(Math.floor((total % 3600) / 60)), pad(total % 60)];
}

export function FlashDeals({ products }: { products: ProductSummary[] }) {
  const [remaining, setRemaining] = useState<number | null>(null);

  // Compte à rebours jusqu'à minuit, mis à jour chaque seconde.
  useEffect(() => {
    const update = () => {
      const end = new Date();
      end.setHours(24, 0, 0, 0);
      setRemaining(end.getTime() - Date.now());
    };
    update();
    const timer = window.setInterval(update, 1000);
    return () => window.clearInterval(timer);
  }, []);

  if (products.length === 0) return null;

  const parts = remaining === null ? ["--", "--", "--"] : formatRemaining(remaining);

  return (
    <section id="flash" className="bg-gradient-to-r from-red-600 via-red-500 to-orange-500">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="flex flex-wrap items-center justify-between gap-4 text-white">
          <div className="flex flex-wrap items-center gap-4">
            <h2 className="text-2xl font-extrabold">⚡ Ventes flash</h2>
            <div className="flex items-center gap-2 text-sm font-medium">
              <span>Se termine dans</span>
              <span className="flex gap-1 font-mono">
                {parts.map((part, index) => (
                  <span key={index} className="rounded bg-white px-2 py-1 font-bold text-red-600">
                    {part}
                  </span>
                ))}
              </span>
            </div>
          </div>
          <Link href="/recherche?tri=ventes" className="text-sm font-semibold hover:underline">
            Tout voir →
          </Link>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
          {products.slice(0, 6).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
