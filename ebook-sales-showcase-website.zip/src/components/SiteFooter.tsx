import Link from "next/link";
import { site } from "@/lib/site";

const columns = [
  {
    title: "Achats",
    links: [
      { href: "/recherche", label: "Tous les produits" },
      { href: "/#flash", label: "Ventes flash" },
      { href: "/panier", label: "Mon panier" },
      { href: "/compte#favoris", label: "Mes favoris" },
    ],
  },
  {
    title: "Mon compte",
    links: [
      { href: "/compte", label: "Mes commandes" },
      { href: "/connexion", label: "Connexion" },
      { href: "/connexion", label: "Créer un compte" },
      { href: "/admin", label: "Administration" },
    ],
  },
  {
    title: "Aide",
    links: [
      { href: "/#contact", label: "Service client" },
      { href: "/#contact", label: "Livraison" },
      { href: "/#contact", label: "Retours et remboursements" },
    ],
  },
];

export function SiteFooter() {
  return (
    <footer className="mt-16 bg-slate-900 text-slate-300">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-4">
        <div>
          <p className="text-xl font-extrabold text-white">{site.name}</p>
          <p className="mt-3 text-sm leading-6 text-slate-400">{site.tagline}.</p>
          <p className="mt-4 text-sm text-slate-400">{site.hours}</p>
          <p className="mt-1 text-sm text-slate-400">{site.email}</p>
        </div>

        {columns.map((column) => (
          <div key={column.title}>
            <p className="text-sm font-semibold uppercase tracking-wider text-white">{column.title}</p>
            <ul className="mt-4 space-y-2.5 text-sm">
              {column.links.map((link) => (
                <li key={link.label}>
                  <Link href={link.href} className="transition hover:text-white">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-6 text-xs text-slate-500 sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} {site.name}. Tous droits réservés.</p>
          <p>Paiements sécurisés · Livraison suivie · Retours sous 30 jours</p>
        </div>
      </div>
    </footer>
  );
}
