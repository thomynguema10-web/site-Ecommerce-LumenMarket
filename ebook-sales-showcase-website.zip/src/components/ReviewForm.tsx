"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

const fieldClass =
  "mt-2 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-orange-500 focus:ring-4 focus:ring-orange-100";

export function ReviewForm({ slug, loggedIn }: { slug: string; loggedIn: boolean }) {
  const router = useRouter();
  const [rating, setRating] = useState(5);
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  if (!loggedIn) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 p-6 text-center">
        <p className="text-slate-600">Connectez-vous pour partager votre avis sur ce produit.</p>
        <Link
          href={`/connexion?next=${encodeURIComponent(`/produit/${slug}`)}`}
          className="mt-4 inline-flex rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-orange-600"
        >
          Se connecter
        </Link>
      </div>
    );
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);

    setStatus("sending");
    setError(null);

    try {
      const response = await fetch(`/api/products/${slug}/reviews`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rating, title: data.get("title"), body: data.get("body") }),
      });
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;

      if (!response.ok) {
        setError(payload?.error ?? "Votre avis n'a pas pu être publié.");
        setStatus("error");
        return;
      }

      form.reset();
      setRating(5);
      setStatus("done");
      router.refresh();
    } catch {
      setError("Connexion impossible. Réessayez.");
      setStatus("error");
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-slate-200 bg-white p-6">
      <p className="font-semibold text-slate-900">Donnez votre avis</p>

      <div className="flex gap-1" role="group" aria-label="Note sur 5">
        {[1, 2, 3, 4, 5].map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => setRating(value)}
            aria-label={`${value} étoile${value > 1 ? "s" : ""}`}
            className={`text-3xl leading-none transition ${value <= rating ? "text-amber-400" : "text-slate-300"}`}
          >
            ★
          </button>
        ))}
      </div>

      <label className="block text-sm font-medium text-slate-700">
        Titre
        <input name="title" required minLength={3} maxLength={120} placeholder="Résumez votre expérience" className={fieldClass} />
      </label>

      <label className="block text-sm font-medium text-slate-700">
        Votre avis
        <textarea name="body" required minLength={10} maxLength={2000} rows={4} placeholder="Qualité, taille, livraison..." className={fieldClass} />
      </label>

      <div className="flex flex-wrap items-center gap-4">
        <button
          type="submit"
          disabled={status === "sending"}
          className="rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white transition hover:bg-orange-600 disabled:opacity-60"
        >
          {status === "sending" ? "Publication..." : "Publier mon avis"}
        </button>
        {status === "done" && <p className="text-sm font-medium text-emerald-700">Merci, votre avis a été publié !</p>}
        {status === "error" && error && <p className="text-sm font-medium text-rose-600">{error}</p>}
      </div>
    </form>
  );
}
