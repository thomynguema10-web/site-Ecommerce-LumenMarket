type StarRatingProps = {
  value: number;
  size?: "xs" | "sm" | "lg";
};

// Étoiles d'évaluation (rendu côté serveur, sans JavaScript).
export function StarRating({ value, size = "sm" }: StarRatingProps) {
  const percent = Math.max(0, Math.min(100, (value / 5) * 100));
  const sizeClass = size === "lg" ? "text-xl" : size === "sm" ? "text-sm" : "text-xs";

  return (
    <span role="img" aria-label={`Note ${value.toFixed(1)} sur 5`} className={`relative inline-block leading-none tracking-[0.08em] ${sizeClass}`}>
      <span className="text-slate-300" aria-hidden="true">★★★★★</span>
      <span className="absolute inset-0 overflow-hidden whitespace-nowrap text-amber-400" style={{ width: `${percent}%` }} aria-hidden="true">
        ★★★★★
      </span>
    </span>
  );
}
