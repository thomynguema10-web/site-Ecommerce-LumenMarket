"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { useCart } from "@/lib/cart";

type HeaderCategory = { slug: string; name: string; icon: string };
type HeaderUser = { name: string; role: string } | null;

export function SiteHeader({ user, categories }: { user: HeaderUser; categories: HeaderCategory[] }) {
  const router = useRouter();
  const { itemCount, ready } = useCart();
  const [query, setQuery] = useState("");

  function handleSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const term = query.trim();
    router.push(term ? `/recherche?q=${encodeURIComponent(term)}` : "/recherche");
  }

  const firstName = user?.name.split(" ")[0] ?? "";

  return (
    <header className="sticky top-0 z-50 shadow-sm">
      <div className="hidden bg-slate-900 text-xs text-slate-200 md:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-1.5">
          <p>🚚 Livraison gratuite dès 35 € · ↩️ Retours gratuits sous 30 jours · 🔒 Paiement sécurisé</p>
          <div className="flex gap-5">
            <Link href="/#flash" className="hover:text-white">Ventes flash</Link>
            <Link href="/#contact" className="hover:text-white">Service client</Link>
          </div>
        </div>
      </div>

      <div className="bg-white">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 md:gap-6">
          <Link href="/" className="shrink-0 text-xl font-extrabold tracking-tight">
            <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">Lumen</span>
            <span className="text-slate-900">Market</span>
          </Link>

          <form onSubmit={handleSearch} role="search" className="flex min-w-0 flex-1 items-center">
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Rechercher des produits, marques..."
              aria-label="Rechercher un produit"
              className="h-11 min-w-0 flex-1 rounded-l-full border-2 border-r-0 border-orange-500 bg-white px-5 text-sm text-slate-900 outline-none placeholder:text-slate-400"
            />
            <button
              type="submit"
              className="h-11 shrink-0 rounded-r-full bg-gradient-to-r from-orange-500 to-red-500 px-5 text-sm font-semibold text-white transition hover:opacity-90"
            >
              Rechercher
            </button>
          </form>

          <div className="flex shrink-0 items-center gap-1 sm:gap-2">
            <Link
              href={user ? "/compte" : "/connexion"}
              className="flex items-center gap-2 rounded-xl px-2 py-2 text-slate-700 transition hover:bg-slate-100"
            >
              <span className="text-lg" aria-hidden="true">👤</span>
              <span className="hidden text-left leading-tight lg:block">
                <span className="block text-[11px] text-slate-500">{user ? `Bonjour ${firstName}` : "Bonjour"}</span>
                <span className="text-sm font-semibold">{user ? "Mon compte" : "Connexion"}</span>
              </span>
            </Link>

            <Link
              href="/compte#favoris"
              aria-label="Mes favoris"
              className="rounded-xl px-2 py-2 text-lg text-slate-700 transition hover:bg-slate-100"
            >
              ♡
            </Link>

            <Link
              href="/panier"
              aria-label="Voir le panier"
              className="relative flex items-center gap-2 rounded-xl px-2 py-2 text-slate-700 transition hover:bg-slate-100"
            >
              <span className="text-lg" aria-hidden="true">🛒</span>
              <span className="hidden text-sm font-semibold lg:inline">Panier</span>
              {ready && itemCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-red-600 px-1 text-[11px] font-bold text-white">
                  {itemCount}
                </span>
              )}
            </Link>
          </div>
        </div>

        <nav aria-label="Catégories" className="border-t border-slate-100">
          <ul className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 py-2 text-sm whitespace-nowrap">
            <li>
              <Link href="/recherche" className="block rounded-full px-3 py-1.5 font-semibold text-slate-900 hover:bg-orange-50 hover:text-orange-600">
                Tout voir
              </Link>
            </li>
            {categories.map((category) => (
              <li key={category.slug}>
                <Link
                  href={`/recherche?categorie=${category.slug}`}
                  className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-slate-700 hover:bg-orange-50 hover:text-orange-600"
                >
                  <span aria-hidden="true">{category.icon}</span>
                  {category.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}
