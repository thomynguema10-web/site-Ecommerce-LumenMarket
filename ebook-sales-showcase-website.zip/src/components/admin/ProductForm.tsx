"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

const fieldClass =
  "mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-100";

function parseEuros(value: FormDataEntryValue | null): number {
  return Math.round(Number(String(value ?? "0").replace(",", ".")) * 100);
}

export function ProductForm({ categories }: { categories: { id: number; name: string }[] }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const priceCents = parseEuros(data.get("price"));

    const images = String(data.get("images") ?? "")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);

    const variants = String(data.get("variants") ?? "")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        const [label = "", stock = "0"] = line.split("|").map((part) => part.trim());
        return { label, stock: Number(stock), priceCents };
      });

    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch("/api/admin/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: data.get("title"),
          brand: data.get("brand"),
          description: data.get("description"),
          categoryId: Number(data.get("categoryId")),
          optionName: data.get("optionName"),
          originalPriceCents: parseEuros(data.get("originalPrice")),
          images,
          variants,
          freeShipping: data.get("freeShipping") === "on",
          flashDeal: data.get("flashDeal") === "on",
          featured: data.get("featured") === "on",
        }),
      });
      const payload = (await response.json().catch(() => null)) as { slug?: string; error?: string } | null;

      if (!response.ok) {
        setMessage({ type: "error", text: payload?.error ?? "Le produit n'a pas pu être créé." });
        return;
      }

      form.reset();
      setMessage({ type: "ok", text: `Produit créé : ${payload?.slug ?? ""}` });
      router.refresh();
    } catch {
      setMessage({ type: "error", text: "Connexion impossible." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-5 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm md:grid-cols-2">
      <label className="block text-sm font-medium text-slate-700 md:col-span-2">
        Titre du produit
        <input name="title" required minLength={3} placeholder="Ex. Enceinte Bluetooth étanche" className={fieldClass} />
      </label>

      <label className="block text-sm font-medium text-slate-700">
        Boutique / marque
        <input name="brand" required minLength={2} placeholder="Nom de la boutique" className={fieldClass} />
      </label>

      <label className="block text-sm font-medium text-slate-700">
        Catégorie
        <select name="categoryId" required className={fieldClass}>
          {categories.map((category) => (
            <option key={category.id} value={category.id}>
              {category.name}
            </option>
          ))}
        </select>
      </label>

      <label className="block text-sm font-medium text-slate-700">
        Prix de vente (€)
        <input name="price" required inputMode="decimal" placeholder="29,90" className={fieldClass} />
      </label>

      <label className="block text-sm font-medium text-slate-700">
        Prix barré (€) <span className="font-normal text-slate-400">(optionnel)</span>
        <input name="originalPrice" inputMode="decimal" placeholder="49,90" className={fieldClass} />
      </label>

      <label className="block text-sm font-medium text-slate-700">
        Nom de l&apos;option
        <input name="optionName" placeholder="Couleur, Taille..." defaultValue="Couleur" className={fieldClass} />
      </label>

      <div className="flex flex-wrap items-center gap-5 self-end text-sm font-medium text-slate-700">
        <label className="flex items-center gap-2"><input type="checkbox" name="freeShipping" className="h-4 w-4 accent-orange-500" /> Livraison gratuite</label>
        <label className="flex items-center gap-2"><input type="checkbox" name="flashDeal" className="h-4 w-4 accent-orange-500" /> Vente flash</label>
        <label className="flex items-center gap-2"><input type="checkbox" name="featured" className="h-4 w-4 accent-orange-500" /> Mis en avant</label>
      </div>

      <label className="block text-sm font-medium text-slate-700 md:col-span-2">
        Description
        <textarea name="description" required minLength={10} rows={3} placeholder="Décrivez le produit..." className={fieldClass} />
      </label>

      <label className="block text-sm font-medium text-slate-700">
        Images (une URL https par ligne)
        <textarea name="images" required rows={4} placeholder={"https://exemple.com/photo-1.jpg"} className={`${fieldClass} font-mono text-xs`} />
      </label>

      <label className="block text-sm font-medium text-slate-700">
        Variantes (une par ligne : libellé | stock)
        <textarea name="variants" required rows={4} placeholder={"Noir | 20\nBlanc | 15"} className={`${fieldClass} font-mono text-xs`} />
      </label>

      <div className="flex flex-wrap items-center gap-4 md:col-span-2">
        <button
          type="submit"
          disabled={busy}
          className="rounded-xl bg-gradient-to-r from-orange-500 to-red-500 px-6 py-3 text-sm font-bold text-white transition hover:opacity-90 disabled:opacity-60"
        >
          {busy ? "Création..." : "Publier le produit"}
        </button>
        {message && (
          <p className={`text-sm font-medium ${message.type === "ok" ? "text-emerald-700" : "text-rose-600"}`}>{message.text}</p>
        )}
      </div>
    </form>
  );
}
