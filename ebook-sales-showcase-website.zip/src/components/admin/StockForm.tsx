"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function StockForm({
  variantId,
  label,
  stock,
  priceCents,
}: {
  variantId: number;
  label: string;
  stock: number;
  priceCents: number;
}) {
  const router = useRouter();
  const [stockValue, setStockValue] = useState(String(stock));
  const [priceValue, setPriceValue] = useState((priceCents / 100).toFixed(2));
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function save() {
    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch(`/api/admin/variants/${variantId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          stock: Number(stockValue),
          priceCents: Math.round(Number(priceValue.replace(",", ".")) * 100),
        }),
      });
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;
      setMessage(response.ok ? "OK" : payload?.error ?? "Erreur");
      if (response.ok) router.refresh();
    } catch {
      setMessage("Connexion impossible");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-3 py-2 text-sm">
      <span className="w-44 truncate font-medium text-slate-700">{label}</span>
      <label className="flex items-center gap-1.5 text-xs text-slate-500">
        Stock
        <input
          type="number"
          min={0}
          value={stockValue}
          onChange={(event) => setStockValue(event.target.value)}
          className="w-24 rounded-lg border border-slate-300 px-2 py-1 text-sm text-slate-900"
        />
      </label>
      <label className="flex items-center gap-1.5 text-xs text-slate-500">
        Prix (€)
        <input
          type="text"
          inputMode="decimal"
          value={priceValue}
          onChange={(event) => setPriceValue(event.target.value)}
          className="w-24 rounded-lg border border-slate-300 px-2 py-1 text-sm text-slate-900"
        />
      </label>
      <button
        type="button"
        onClick={save}
        disabled={busy}
        className="rounded-lg border border-slate-300 px-3 py-1 text-xs font-semibold text-slate-700 hover:border-orange-400 hover:text-orange-600 disabled:opacity-60"
      >
        Mettre à jour
      </button>
      {message && <span className="text-xs text-slate-500">{message}</span>}
    </div>
  );
}
