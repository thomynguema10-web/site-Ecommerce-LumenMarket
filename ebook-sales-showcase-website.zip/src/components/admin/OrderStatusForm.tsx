"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { ORDER_STATUS_LABELS } from "@/lib/site";

const STATUSES = ["paid", "preparing", "shipped", "delivered", "cancelled"] as const;

export function OrderStatusForm({
  orderId,
  status,
  trackingNumber,
}: {
  orderId: string;
  status: string;
  trackingNumber: string | null;
}) {
  const router = useRouter();
  const [value, setValue] = useState(status);
  const [tracking, setTracking] = useState(trackingNumber ?? "");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function save() {
    setBusy(true);
    setMessage(null);
    try {
      const response = await fetch(`/api/admin/orders/${orderId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: value, trackingNumber: tracking }),
      });
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;
      setMessage(response.ok ? "Enregistré ✓" : payload?.error ?? "Erreur");
      if (response.ok) router.refresh();
    } catch {
      setMessage("Connexion impossible");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <select
        value={value}
        onChange={(event) => setValue(event.target.value)}
        className="rounded-lg border border-slate-300 px-2 py-1.5 text-sm"
        aria-label="Statut de la commande"
      >
        {STATUSES.map((item) => (
          <option key={item} value={item}>
            {ORDER_STATUS_LABELS[item]}
          </option>
        ))}
      </select>
      <input
        value={tracking}
        onChange={(event) => setTracking(event.target.value)}
        placeholder="N° de suivi"
        aria-label="Numéro de suivi"
        className="w-36 rounded-lg border border-slate-300 px-2 py-1.5 text-sm"
      />
      <button
        type="button"
        onClick={save}
        disabled={busy}
        className="rounded-lg bg-slate-900 px-3 py-1.5 text-sm font-semibold text-white hover:bg-orange-600 disabled:opacity-60"
      >
        Enregistrer
      </button>
      {message && <span className="text-xs text-slate-500">{message}</span>}
    </div>
  );
}
