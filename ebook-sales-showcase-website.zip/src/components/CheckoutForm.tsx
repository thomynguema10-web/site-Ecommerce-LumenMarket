"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { fetchQuote, useCart, type QuoteResponse } from "@/lib/cart";
import { formatPrice } from "@/lib/site";

const COUNTRIES = ["France", "Belgique", "Suisse", "Luxembourg", "Canada", "Monaco"];

const fieldClass =
  "mt-2 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-orange-500 focus:ring-4 focus:ring-orange-100";

export function CheckoutForm({ user }: { user: { name: string; email: string } | null }) {
  const router = useRouter();
  const { items, ready, coupon, setCoupon, clear } = useCart();
  const [quote, setQuote] = useState<QuoteResponse | null>(null);
  const [shippingMethod, setShippingMethod] = useState("standard");
  const [couponInput, setCouponInput] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const itemsKey = JSON.stringify(items.map((item) => [item.variantId, item.quantity]));

  useEffect(() => {
    if (!ready || items.length === 0) return;
    let active = true;
    fetchQuote(items, shippingMethod, coupon)
      .then((result) => {
        if (active) setQuote(result);
      })
      .catch(() => {
        if (active) setError("Impossible de calculer le total de votre commande.");
      });
    return () => {
      active = false;
    };
    // Le contenu du panier est suivi via itemsKey pour éviter les recalculs inutiles.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, itemsKey, shippingMethod, coupon]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!quote || quote.hasUnavailable) {
      setError("Mettez votre panier à jour avant de valider la commande.");
      return;
    }

    const form = new FormData(event.currentTarget);
    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((item) => ({ variantId: item.variantId, quantity: item.quantity })),
          shipping: {
            fullName: form.get("fullName"),
            email: form.get("email"),
            phone: form.get("phone"),
            address: form.get("address"),
            postalCode: form.get("postalCode"),
            city: form.get("city"),
            country: form.get("country"),
          },
          shippingMethod,
          couponCode: coupon,
        }),
      });
      const payload = (await response.json().catch(() => null)) as { id?: string; error?: string } | null;

      if (!response.ok || !payload?.id) {
        setError(payload?.error ?? "La commande n'a pas pu être finalisée. Réessayez.");
        setSubmitting(false);
        return;
      }

      clear();
      router.push(`/commandes/${payload.id}`);
    } catch {
      setError("Connexion impossible. Vérifiez votre réseau et réessayez.");
      setSubmitting(false);
    }
  }

  function applyCoupon() {
    setCoupon(couponInput.trim() || null);
    setCouponInput("");
  }

  if (!ready) {
    return <div className="py-24 text-center text-slate-500">Chargement de votre panier...</div>;
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-lg py-24 text-center">
        {submitting ? (
          <p className="text-lg text-slate-600">Commande validée, redirection en cours...</p>
        ) : (
          <>
            <p className="text-5xl" aria-hidden="true">🛒</p>
            <h1 className="mt-6 text-2xl font-extrabold text-slate-900">Votre panier est vide</h1>
            <Link href="/recherche" className="mt-6 inline-flex rounded-xl bg-orange-500 px-6 py-3 font-semibold text-white hover:bg-orange-600">
              Découvrir les produits
            </Link>
          </>
        )}
      </div>
    );
  }

  const selectedOption = quote?.shippingOptions.find((option) => option.id === shippingMethod);

  return (
    <div className="grid gap-8 lg:grid-cols-5">
      <form onSubmit={handleSubmit} className="space-y-8 lg:col-span-3">
        <section className="space-y-5 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
          <h2 className="text-lg font-bold text-slate-900">1. Coordonnées et livraison</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="block text-sm font-medium text-slate-700">
              Nom complet
              <input name="fullName" required minLength={2} autoComplete="name" defaultValue={user?.name ?? ""} className={fieldClass} />
            </label>
            <label className="block text-sm font-medium text-slate-700">
              E-mail
              <input name="email" type="email" required autoComplete="email" defaultValue={user?.email ?? ""} className={fieldClass} />
            </label>
            <label className="block text-sm font-medium text-slate-700">
              Téléphone
              <input name="phone" type="tel" required autoComplete="tel" placeholder="06 12 34 56 78" className={fieldClass} />
            </label>
            <label className="block text-sm font-medium text-slate-700">
              Pays
              <select name="country" defaultValue="France" className={fieldClass}>
                {COUNTRIES.map((country) => (
                  <option key={country} value={country}>
                    {country}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-sm font-medium text-slate-700 sm:col-span-2">
              Adresse
              <input name="address" required minLength={5} autoComplete="street-address" placeholder="12 rue de la Paix" className={fieldClass} />
            </label>
            <label className="block text-sm font-medium text-slate-700">
              Code postal
              <input name="postalCode" required minLength={3} autoComplete="postal-code" className={fieldClass} />
            </label>
            <label className="block text-sm font-medium text-slate-700">
              Ville
              <input name="city" required minLength={2} autoComplete="address-level2" className={fieldClass} />
            </label>
          </div>
        </section>

        <section className="space-y-4 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
          <h2 className="text-lg font-bold text-slate-900">2. Mode de livraison</h2>
          <div className="space-y-3">
            {(quote?.shippingOptions ?? []).map((option) => (
              <label
                key={option.id}
                className={`flex cursor-pointer items-center justify-between gap-4 rounded-2xl border-2 p-4 transition ${
                  shippingMethod === option.id ? "border-orange-500 bg-orange-50/60" : "border-slate-200 hover:border-slate-300"
                }`}
              >
                <span className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="shippingMethod"
                    value={option.id}
                    checked={shippingMethod === option.id}
                    onChange={() => setShippingMethod(option.id)}
                    className="h-4 w-4 accent-orange-500"
                  />
                  <span>
                    <span className="block font-semibold text-slate-900">{option.label}</span>
                    <span className="block text-sm text-slate-500">{option.delay}</span>
                  </span>
                </span>
                <span className="font-bold text-slate-900">{option.priceCents === 0 ? "Gratuite" : formatPrice(option.priceCents)}</span>
              </label>
            ))}
            {!quote && <p className="text-sm text-slate-500">Calcul des options de livraison...</p>}
          </div>
        </section>

        <section className="rounded-3xl border border-amber-200 bg-amber-50 p-6">
          <h2 className="text-lg font-bold text-slate-900">3. Paiement</h2>
          <p className="mt-2 text-sm text-amber-900">
            Mode démonstration : le paiement est simulé et la commande est validée immédiatement.
          </p>
        </section>

        {error && <p className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700">{error}</p>}

        <button
          type="submit"
          disabled={submitting || !quote || quote.hasUnavailable}
          className="w-full rounded-2xl bg-gradient-to-r from-orange-500 to-red-500 px-6 py-4 text-lg font-extrabold text-white shadow-lg shadow-orange-500/25 transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {submitting ? "Validation en cours..." : `Payer ${quote ? formatPrice(quote.totalCents) : ""}`}
        </button>
      </form>

      <aside className="h-fit space-y-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm lg:col-span-2 lg:sticky lg:top-44">
        <h2 className="text-lg font-bold text-slate-900">Récapitulatif</h2>

        <ul className="max-h-80 space-y-4 overflow-y-auto pr-1">
          {(quote?.lines ?? []).map((line) => (
            <li key={line.variantId} className="flex gap-3 text-sm">
              <span className="flex-1">
                <span className="line-clamp-2 font-medium text-slate-800">{line.title}</span>
                <span className="block text-xs text-slate-500">
                  {line.label} × {line.quantity}
                </span>
              </span>
              <span className="shrink-0 font-semibold text-slate-900">{formatPrice(line.lineTotalCents)}</span>
            </li>
          ))}
        </ul>

        <div className="flex gap-2">
          <input
            value={couponInput}
            onChange={(event) => setCouponInput(event.target.value)}
            placeholder={coupon ? `Code appliqué : ${coupon}` : "Code promo"}
            className="min-w-0 flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm uppercase outline-none focus:border-orange-500"
          />
          <button type="button" onClick={applyCoupon} className="rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white hover:bg-orange-600">
            Appliquer
          </button>
        </div>
        {quote?.couponError && <p className="text-xs font-medium text-rose-600">{quote.couponError}</p>}

        <dl className="space-y-2 border-t border-slate-200 pt-5 text-sm">
          <div className="flex justify-between text-slate-600">
            <dt>Articles</dt>
            <dd>{formatPrice(quote?.subtotalCents ?? 0)}</dd>
          </div>
          {quote && quote.discountCents > 0 && (
            <div className="flex justify-between text-emerald-600">
              <dt>Réduction</dt>
              <dd>−{formatPrice(quote.discountCents)}</dd>
            </div>
          )}
          <div className="flex justify-between text-slate-600">
            <dt>Livraison</dt>
            <dd>{selectedOption ? (selectedOption.priceCents === 0 ? "Gratuite" : formatPrice(selectedOption.priceCents)) : "—"}</dd>
          </div>
          <div className="flex justify-between border-t border-slate-200 pt-3 text-lg font-extrabold text-slate-900">
            <dt>Total TTC</dt>
            <dd>{formatPrice(quote?.totalCents ?? 0)}</dd>
          </div>
        </dl>

        <p className="text-xs leading-5 text-slate-500">
          🔒 Vos données sont traitées de façon confidentielle. Vous retrouverez le suivi de votre commande dans votre compte.
        </p>
      </aside>
    </div>
  );
}
