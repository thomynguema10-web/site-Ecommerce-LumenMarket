"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

const fieldClass =
  "mt-2 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-orange-500 focus:ring-4 focus:ring-orange-100";

export function AuthForm({ next }: { next: string }) {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const payload =
      mode === "login"
        ? { email: data.get("email"), password: data.get("password") }
        : { name: data.get("name"), email: data.get("email"), password: data.get("password") };

    setBusy(true);
    setError(null);

    try {
      const response = await fetch(mode === "login" ? "/api/auth/login" : "/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = (await response.json().catch(() => null)) as { error?: string } | null;

      if (!response.ok) {
        setError(result?.error ?? "Une erreur est survenue.");
        setBusy(false);
        return;
      }

      router.replace(next);
      router.refresh();
    } catch {
      setError("Connexion impossible. Réessayez.");
      setBusy(false);
    }
  }

  const tabClass = (active: boolean) =>
    `flex-1 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
      active ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-800"
    }`;

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
      <div role="tablist" className="mb-8 flex gap-1 rounded-2xl bg-slate-100 p-1">
        <button type="button" role="tab" aria-selected={mode === "login"} onClick={() => setMode("login")} className={tabClass(mode === "login")}>
          Se connecter
        </button>
        <button type="button" role="tab" aria-selected={mode === "register"} onClick={() => setMode("register")} className={tabClass(mode === "register")}>
          Créer un compte
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {mode === "register" && (
          <label className="block text-sm font-medium text-slate-700">
            Nom complet
            <input name="name" required minLength={2} autoComplete="name" placeholder="Jean Dupont" className={fieldClass} />
          </label>
        )}
        <label className="block text-sm font-medium text-slate-700">
          Adresse e-mail
          <input name="email" type="email" required autoComplete="email" placeholder="vous@exemple.fr" className={fieldClass} />
        </label>
        <label className="block text-sm font-medium text-slate-700">
          Mot de passe
          <input
            name="password"
            type="password"
            required
            minLength={8}
            autoComplete={mode === "login" ? "current-password" : "new-password"}
            placeholder={mode === "register" ? "8 caractères minimum" : "Votre mot de passe"}
            className={fieldClass}
          />
        </label>

        {error && <p className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700">{error}</p>}

        <button
          type="submit"
          disabled={busy}
          className="w-full rounded-xl bg-gradient-to-r from-orange-500 to-red-500 px-6 py-3.5 font-bold text-white transition hover:opacity-90 disabled:opacity-60"
        >
          {busy ? "Veuillez patienter..." : mode === "login" ? "Se connecter" : "Créer mon compte"}
        </button>
      </form>
    </div>
  );
}
