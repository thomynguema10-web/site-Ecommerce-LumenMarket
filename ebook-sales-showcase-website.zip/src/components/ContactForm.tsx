"use client";

import { useState, type FormEvent } from "react";

type Status = "idle" | "sending" | "success" | "error";

export function ContactForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());

    setStatus("sending");
    setError(null);

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;

      if (!response.ok) {
        setError(payload?.error ?? "Le message n'a pas pu être envoyé.");
        setStatus("error");
        return;
      }

      form.reset();
      setStatus("success");
    } catch {
      setError("Connexion impossible. Réessayez dans quelques instants.");
      setStatus("error");
    }
  }

  const inputClass =
    "mt-2 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100";

  return (
    <form onSubmit={handleSubmit} className="grid gap-5 sm:grid-cols-2">
      <label className="block text-sm font-medium text-slate-700">
        Nom complet
        <input name="name" required minLength={2} placeholder="Jean Dupont" className={inputClass} />
      </label>
      <label className="block text-sm font-medium text-slate-700">
        Adresse e-mail
        <input name="email" type="email" required placeholder="vous@exemple.fr" className={inputClass} />
      </label>
      <label className="block text-sm font-medium text-slate-700 sm:col-span-2">
        Entreprise <span className="font-normal text-slate-400">(optionnel)</span>
        <input name="company" placeholder="Votre société" className={inputClass} />
      </label>
      <label className="block text-sm font-medium text-slate-700 sm:col-span-2">
        Votre message
        <textarea
          name="message"
          required
          minLength={10}
          rows={5}
          placeholder="Décrivez votre projet ou votre question..."
          className={inputClass}
        />
      </label>

      <div className="sm:col-span-2 flex flex-wrap items-center gap-4">
        <button
          type="submit"
          disabled={status === "sending"}
          className="rounded-xl bg-slate-950 px-6 py-3.5 text-sm font-semibold text-white transition hover:bg-indigo-600 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {status === "sending" ? "Envoi en cours..." : "Envoyer le message"}
        </button>
        {status === "success" && (
          <p className="text-sm font-medium text-emerald-700">Merci ! Nous vous répondons sous 48 h ouvrées.</p>
        )}
        {status === "error" && error && <p className="text-sm font-medium text-rose-600">{error}</p>}
      </div>
    </form>
  );
}
