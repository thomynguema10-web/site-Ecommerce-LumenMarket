import Image from "next/image";
import Link from "next/link";
import type { ProductSummary } from "@/lib/catalog";
import { discountPercent, formatCount, formatPrice } from "@/lib/site";
import { StarRating } from "./StarRating";

export function ProductCard({ product }: { product: ProductSummary }) {
  const discount = discountPercent(product.originalPriceCents, product.priceCents);
  const image = product.images[0];

  return (
    <Link
      href={`/produit/${product.slug}`}
      className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white transition duration-300 hover:-translate-y-0.5 hover:shadow-xl"
    >
      <div className="relative aspect-square overflow-hidden bg-slate-100">
        {image && (
          <Image
            src={image}
            alt={product.title}
            fill
            sizes="(min-width: 1280px) 20vw, (min-width: 768px) 33vw, 50vw"
            className="object-cover transition duration-500 group-hover:scale-105"
          />
        )}
        {discount > 0 && (
          <span className="absolute left-2 top-2 rounded-md bg-red-600 px-2 py-0.5 text-xs font-bold text-white">
            -{discount}%
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-3">
        <h3 className="line-clamp-2 min-h-[2.5rem] text-sm leading-5 text-slate-800 group-hover:text-orange-600">
          {product.title}
        </h3>
        <p className="mt-1 truncate text-xs text-slate-500">{product.brand}</p>

        <div className="mt-1.5 flex items-center gap-1.5 text-xs text-slate-500">
          <StarRating value={product.ratingAverage} size="xs" />
          <span>({product.reviewCount})</span>
        </div>

        <div className="mt-auto pt-3">
          <div className="flex flex-wrap items-baseline gap-x-2">
            <span className="text-lg font-bold text-red-600">{formatPrice(product.priceCents)}</span>
            {discount > 0 && (
              <span className="text-xs text-slate-400 line-through">{formatPrice(product.originalPriceCents)}</span>
            )}
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-2 text-xs text-slate-500">
            <span>{formatCount(product.soldCount)} vendus</span>
            {product.freeShipping && <span className="font-medium text-emerald-600">Livraison gratuite</span>}
          </div>
        </div>
      </div>
    </Link>
  );
}
